// Protocol Buffers - Google's data interchange format
// Copyright 2015 Google Inc.  All rights reserved.
// https://developers.google.com/protocol-buffers/
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are
// met:
//
//     * Redistributions of source code must retain the above copyright
// notice, this list of conditions and the following disclaimer.
//     * Redistributions in binary form must reproduce the above
// copyright notice, this list of conditions and the following disclaimer
// in the documentation and/or other materials provided with the
// distribution.
//     * Neither the name of Google Inc. nor the names of its
// contributors may be used to endorse or promote products derived from
// this software without specific prior written permission.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
// "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
// LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
// A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
// OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
// SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
// LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
// DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
// THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#import <Foundation/Foundation.h>
#import <XCTest/XCTest.h>

#import "GPBDictionary.h"

#import "GPBTestUtilities.h"
#import "google/protobuf/UnittestRuntimeProto2.pbobjc.h"

// Pull in the macros (using an external file because expanding all tests
// in a single file makes a file that is failing to work with within Xcode.
//%PDDM-IMPORT-DEFINES GPBDictionaryTests.pddm

//%PDDM-EXPAND TESTS_FOR_POD_VALUES(String, NSString, *, Objects, @"foo", @"bar", @"baz", @"mumble")
// This block of code is generated, do not edit it directly.

// To let the testing macros work, add some extra methods to simplify things.
@interface GPBStringEnumDictionary (TestingTweak)
+ (instancetype)dictionaryWithValue:(int32_t)value forKey:(NSString *)key;
- (instancetype)initWithValues:(const int32_t [])values
                       forKeys:(const NSString * [])keys
                         count:(NSUInteger)count;
@end

static BOOL TestingEnum_IsValidValue(int32_t value) {
  switch (value) {
    case 700:
    case 701:
    case 702:
    case 703:
      return YES;
    default:
      return NO;
  }
}

@implementation GPBStringEnumDictionary (TestingTweak)
+ (instancetype)dictionaryWithValue:(int32_t)value forKey:(NSString *)key {
  // Cast is needed to compiler knows what class we are invoking initWithValues: on to get the
  // type correct.
  return [[(GPBStringEnumDictionary*)[self alloc] initWithValidationFunction:TestingEnum_IsValidValue
                                                                   rawValues:&value
                                                                     forKeys:&key
                                                                       count:1] autorelease];
}
- (instancetype)initWithValues:(const int32_t [])values
                       forKeys:(const NSString * [])keys
                         count:(NSUInteger)count {
  return [self initWithValidationFunction:TestingEnum_IsValidValue
                                rawValues:values
                                  forKeys:keys
                                    count:count];
}
@end


#pragma mark - String -> UInt32

@interface GPBStringUInt32DictionaryTests : XCTestCase
@end

@implementation GPBStringUInt32DictionaryTests

- (void)testEmpty {
  GPBStringUInt32Dictionary *dict = [[GPBStringUInt32Dictionary alloc] init];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 0U);
  XCTAssertFalse([dict valueForKey:@"foo" value:NULL]);
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, uint32_t aValue, BOOL *stop) {
    #pragma unused(aKey, aValue, stop)
    XCTFail(@"Shouldn't get here!");
  }];
  [dict release];
}

- (void)testOne {
  GPBStringUInt32Dictionary *dict = [GPBStringUInt32Dictionary dictionaryWithValue:100U forKey:@"foo"];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 1U);
  uint32_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 100U);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, uint32_t aValue, BOOL *stop) {
    XCTAssertEqualObjects(aKey, @"foo");
    XCTAssertEqual(aValue, 100U);
    XCTAssertNotEqual(stop, NULL);
  }];
}

- (void)testBasics {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz" };
  const uint32_t kValues[] = { 100U, 101U, 102U };
  GPBStringUInt32Dictionary *dict =
      [[GPBStringUInt32Dictionary alloc] initWithValues:kValues
                                                forKeys:kKeys
                                                  count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 3U);
  uint32_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 100U);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 101U);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 102U);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);

  __block NSUInteger idx = 0;
  NSString **seenKeys = malloc(3 * sizeof(NSString*));
  uint32_t *seenValues = malloc(3 * sizeof(uint32_t));
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, uint32_t aValue, BOOL *stop) {
    XCTAssertLessThan(idx, 3U);
    seenKeys[idx] = aKey;
    seenValues[idx] = aValue;
    XCTAssertNotEqual(stop, NULL);
    ++idx;
  }];
  for (int i = 0; i < 3; ++i) {
    BOOL foundKey = NO;
    for (int j = 0; (j < 3) && !foundKey; ++j) {
      if ([kKeys[i] isEqual:seenKeys[j]]) {
        foundKey = YES;
        XCTAssertEqual(kValues[i], seenValues[j], @"i = %d, j = %d", i, j);
      }
    }
    XCTAssertTrue(foundKey, @"i = %d", i);
  }
  free(seenKeys);
  free(seenValues);

  // Stopping the enumeration.
  idx = 0;
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, uint32_t aValue, BOOL *stop) {
    #pragma unused(aKey, aValue)
    if (idx == 1) *stop = YES;
    XCTAssertNotEqual(idx, 2U);
    ++idx;
  }];
  [dict release];
}

- (void)testEquality {
  const NSString *kKeys1[] = { @"foo", @"bar", @"baz", @"mumble" };
  const NSString *kKeys2[] = { @"bar", @"foo", @"mumble" };
  const uint32_t kValues1[] = { 100U, 101U, 102U };
  const uint32_t kValues2[] = { 100U, 103U, 102U };
  const uint32_t kValues3[] = { 100U, 101U, 102U, 103U };
  GPBStringUInt32Dictionary *dict1 =
      [[GPBStringUInt32Dictionary alloc] initWithValues:kValues1
                                                forKeys:kKeys1
                                                  count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict1);
  GPBStringUInt32Dictionary *dict1prime =
      [[GPBStringUInt32Dictionary alloc] initWithValues:kValues1
                                                forKeys:kKeys1
                                                  count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict1prime);
  GPBStringUInt32Dictionary *dict2 =
      [[GPBStringUInt32Dictionary alloc] initWithValues:kValues2
                                                forKeys:kKeys1
                                                  count:GPBARRAYSIZE(kValues2)];
  XCTAssertNotNil(dict2);
  GPBStringUInt32Dictionary *dict3 =
      [[GPBStringUInt32Dictionary alloc] initWithValues:kValues1
                                                forKeys:kKeys2
                                                  count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict3);
  GPBStringUInt32Dictionary *dict4 =
      [[GPBStringUInt32Dictionary alloc] initWithValues:kValues3
                                                forKeys:kKeys1
                                                  count:GPBARRAYSIZE(kValues3)];
  XCTAssertNotNil(dict4);

  // 1/1Prime should be different objects, but equal.
  XCTAssertNotEqual(dict1, dict1prime);
  XCTAssertEqualObjects(dict1, dict1prime);
  // Equal, so they must have same hash.
  XCTAssertEqual([dict1 hash], [dict1prime hash]);

  // 2 is same keys, different values; not equal.
  XCTAssertNotEqualObjects(dict1, dict2);

  // 3 is different keys, same values; not equal.
  XCTAssertNotEqualObjects(dict1, dict3);

  // 4 extra pair; not equal
  XCTAssertNotEqualObjects(dict1, dict4);

  [dict1 release];
  [dict1prime release];
  [dict2 release];
  [dict3 release];
  [dict4 release];
}

- (void)testCopy {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const uint32_t kValues[] = { 100U, 101U, 102U, 103U };
  GPBStringUInt32Dictionary *dict =
      [[GPBStringUInt32Dictionary alloc] initWithValues:kValues
                                                forKeys:kKeys
                                                  count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);

  GPBStringUInt32Dictionary *dict2 = [dict copy];
  XCTAssertNotNil(dict2);

  // Should be new object but equal.
  XCTAssertNotEqual(dict, dict2);
  XCTAssertEqualObjects(dict, dict2);
  XCTAssertTrue([dict2 isKindOfClass:[GPBStringUInt32Dictionary class]]);

  [dict2 release];
  [dict release];
}

- (void)testDictionaryFromDictionary {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const uint32_t kValues[] = { 100U, 101U, 102U, 103U };
  GPBStringUInt32Dictionary *dict =
      [[GPBStringUInt32Dictionary alloc] initWithValues:kValues
                                                forKeys:kKeys
                                                  count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);

  GPBStringUInt32Dictionary *dict2 =
      [GPBStringUInt32Dictionary dictionaryWithDictionary:dict];
  XCTAssertNotNil(dict2);

  // Should be new pointer, but equal objects.
  XCTAssertNotEqual(dict, dict2);
  XCTAssertEqualObjects(dict, dict2);
  [dict release];
}

- (void)testAdds {
  GPBStringUInt32Dictionary *dict = [GPBStringUInt32Dictionary dictionary];
  XCTAssertNotNil(dict);

  XCTAssertEqual(dict.count, 0U);
  [dict setValue:100U forKey:@"foo"];
  XCTAssertEqual(dict.count, 1U);

  const NSString *kKeys[] = { @"bar", @"baz", @"mumble" };
  const uint32_t kValues[] = { 101U, 102U, 103U };
  GPBStringUInt32Dictionary *dict2 =
      [[GPBStringUInt32Dictionary alloc] initWithValues:kValues
                                                forKeys:kKeys
                                                  count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict2);
  [dict addEntriesFromDictionary:dict2];
  XCTAssertEqual(dict.count, 4U);

  uint32_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 100U);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 101U);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 102U);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 103U);
  [dict2 release];
}

- (void)testRemove {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const uint32_t kValues[] = { 100U, 101U, 102U, 103U };
  GPBStringUInt32Dictionary *dict =
      [[GPBStringUInt32Dictionary alloc] initWithValues:kValues
                                         forKeys:kKeys
                                           count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 4U);

  [dict removeValueForKey:@"bar"];
  XCTAssertEqual(dict.count, 3U);
  uint32_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 100U);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 102U);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 103U);

  // Remove again does nothing.
  [dict removeValueForKey:@"bar"];
  XCTAssertEqual(dict.count, 3U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 100U);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 102U);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 103U);

  [dict removeValueForKey:@"mumble"];
  XCTAssertEqual(dict.count, 2U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 100U);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 102U);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);

  [dict removeAll];
  XCTAssertEqual(dict.count, 0U);
  XCTAssertFalse([dict valueForKey:@"foo" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"baz" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);
  [dict release];
}

- (void)testInplaceMutation {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const uint32_t kValues[] = { 100U, 101U, 102U, 103U };
  GPBStringUInt32Dictionary *dict =
      [[GPBStringUInt32Dictionary alloc] initWithValues:kValues
                                         forKeys:kKeys
                                           count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 4U);
  uint32_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 100U);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 101U);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 102U);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 103U);

  [dict setValue:103U forKey:@"foo"];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 103U);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 101U);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 102U);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 103U);

  [dict setValue:101U forKey:@"mumble"];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 103U);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 101U);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 102U);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 101U);

  const NSString *kKeys2[] = { @"bar", @"baz" };
  const uint32_t kValues2[] = { 102U, 100U };
  GPBStringUInt32Dictionary *dict2 =
      [[GPBStringUInt32Dictionary alloc] initWithValues:kValues2
                                                forKeys:kKeys2
                                                  count:GPBARRAYSIZE(kValues2)];
  XCTAssertNotNil(dict2);
  [dict addEntriesFromDictionary:dict2];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 103U);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 102U);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 100U);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 101U);

  [dict2 release];
  [dict release];
}

@end

#pragma mark - String -> Int32

@interface GPBStringInt32DictionaryTests : XCTestCase
@end

@implementation GPBStringInt32DictionaryTests

- (void)testEmpty {
  GPBStringInt32Dictionary *dict = [[GPBStringInt32Dictionary alloc] init];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 0U);
  XCTAssertFalse([dict valueForKey:@"foo" value:NULL]);
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, int32_t aValue, BOOL *stop) {
    #pragma unused(aKey, aValue, stop)
    XCTFail(@"Shouldn't get here!");
  }];
  [dict release];
}

- (void)testOne {
  GPBStringInt32Dictionary *dict = [GPBStringInt32Dictionary dictionaryWithValue:200 forKey:@"foo"];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 1U);
  int32_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 200);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, int32_t aValue, BOOL *stop) {
    XCTAssertEqualObjects(aKey, @"foo");
    XCTAssertEqual(aValue, 200);
    XCTAssertNotEqual(stop, NULL);
  }];
}

- (void)testBasics {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz" };
  const int32_t kValues[] = { 200, 201, 202 };
  GPBStringInt32Dictionary *dict =
      [[GPBStringInt32Dictionary alloc] initWithValues:kValues
                                               forKeys:kKeys
                                                 count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 3U);
  int32_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 200);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 201);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 202);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);

  __block NSUInteger idx = 0;
  NSString **seenKeys = malloc(3 * sizeof(NSString*));
  int32_t *seenValues = malloc(3 * sizeof(int32_t));
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, int32_t aValue, BOOL *stop) {
    XCTAssertLessThan(idx, 3U);
    seenKeys[idx] = aKey;
    seenValues[idx] = aValue;
    XCTAssertNotEqual(stop, NULL);
    ++idx;
  }];
  for (int i = 0; i < 3; ++i) {
    BOOL foundKey = NO;
    for (int j = 0; (j < 3) && !foundKey; ++j) {
      if ([kKeys[i] isEqual:seenKeys[j]]) {
        foundKey = YES;
        XCTAssertEqual(kValues[i], seenValues[j], @"i = %d, j = %d", i, j);
      }
    }
    XCTAssertTrue(foundKey, @"i = %d", i);
  }
  free(seenKeys);
  free(seenValues);

  // Stopping the enumeration.
  idx = 0;
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, int32_t aValue, BOOL *stop) {
    #pragma unused(aKey, aValue)
    if (idx == 1) *stop = YES;
    XCTAssertNotEqual(idx, 2U);
    ++idx;
  }];
  [dict release];
}

- (void)testEquality {
  const NSString *kKeys1[] = { @"foo", @"bar", @"baz", @"mumble" };
  const NSString *kKeys2[] = { @"bar", @"foo", @"mumble" };
  const int32_t kValues1[] = { 200, 201, 202 };
  const int32_t kValues2[] = { 200, 203, 202 };
  const int32_t kValues3[] = { 200, 201, 202, 203 };
  GPBStringInt32Dictionary *dict1 =
      [[GPBStringInt32Dictionary alloc] initWithValues:kValues1
                                               forKeys:kKeys1
                                                 count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict1);
  GPBStringInt32Dictionary *dict1prime =
      [[GPBStringInt32Dictionary alloc] initWithValues:kValues1
                                               forKeys:kKeys1
                                                 count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict1prime);
  GPBStringInt32Dictionary *dict2 =
      [[GPBStringInt32Dictionary alloc] initWithValues:kValues2
                                               forKeys:kKeys1
                                                 count:GPBARRAYSIZE(kValues2)];
  XCTAssertNotNil(dict2);
  GPBStringInt32Dictionary *dict3 =
      [[GPBStringInt32Dictionary alloc] initWithValues:kValues1
                                               forKeys:kKeys2
                                                 count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict3);
  GPBStringInt32Dictionary *dict4 =
      [[GPBStringInt32Dictionary alloc] initWithValues:kValues3
                                               forKeys:kKeys1
                                                 count:GPBARRAYSIZE(kValues3)];
  XCTAssertNotNil(dict4);

  // 1/1Prime should be different objects, but equal.
  XCTAssertNotEqual(dict1, dict1prime);
  XCTAssertEqualObjects(dict1, dict1prime);
  // Equal, so they must have same hash.
  XCTAssertEqual([dict1 hash], [dict1prime hash]);

  // 2 is same keys, different values; not equal.
  XCTAssertNotEqualObjects(dict1, dict2);

  // 3 is different keys, same values; not equal.
  XCTAssertNotEqualObjects(dict1, dict3);

  // 4 extra pair; not equal
  XCTAssertNotEqualObjects(dict1, dict4);

  [dict1 release];
  [dict1prime release];
  [dict2 release];
  [dict3 release];
  [dict4 release];
}

- (void)testCopy {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const int32_t kValues[] = { 200, 201, 202, 203 };
  GPBStringInt32Dictionary *dict =
      [[GPBStringInt32Dictionary alloc] initWithValues:kValues
                                               forKeys:kKeys
                                                 count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);

  GPBStringInt32Dictionary *dict2 = [dict copy];
  XCTAssertNotNil(dict2);

  // Should be new object but equal.
  XCTAssertNotEqual(dict, dict2);
  XCTAssertEqualObjects(dict, dict2);
  XCTAssertTrue([dict2 isKindOfClass:[GPBStringInt32Dictionary class]]);

  [dict2 release];
  [dict release];
}

- (void)testDictionaryFromDictionary {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const int32_t kValues[] = { 200, 201, 202, 203 };
  GPBStringInt32Dictionary *dict =
      [[GPBStringInt32Dictionary alloc] initWithValues:kValues
                                               forKeys:kKeys
                                                 count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);

  GPBStringInt32Dictionary *dict2 =
      [GPBStringInt32Dictionary dictionaryWithDictionary:dict];
  XCTAssertNotNil(dict2);

  // Should be new pointer, but equal objects.
  XCTAssertNotEqual(dict, dict2);
  XCTAssertEqualObjects(dict, dict2);
  [dict release];
}

- (void)testAdds {
  GPBStringInt32Dictionary *dict = [GPBStringInt32Dictionary dictionary];
  XCTAssertNotNil(dict);

  XCTAssertEqual(dict.count, 0U);
  [dict setValue:200 forKey:@"foo"];
  XCTAssertEqual(dict.count, 1U);

  const NSString *kKeys[] = { @"bar", @"baz", @"mumble" };
  const int32_t kValues[] = { 201, 202, 203 };
  GPBStringInt32Dictionary *dict2 =
      [[GPBStringInt32Dictionary alloc] initWithValues:kValues
                                               forKeys:kKeys
                                                 count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict2);
  [dict addEntriesFromDictionary:dict2];
  XCTAssertEqual(dict.count, 4U);

  int32_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 200);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 201);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 202);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 203);
  [dict2 release];
}

- (void)testRemove {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const int32_t kValues[] = { 200, 201, 202, 203 };
  GPBStringInt32Dictionary *dict =
      [[GPBStringInt32Dictionary alloc] initWithValues:kValues
                                        forKeys:kKeys
                                          count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 4U);

  [dict removeValueForKey:@"bar"];
  XCTAssertEqual(dict.count, 3U);
  int32_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 200);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 202);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 203);

  // Remove again does nothing.
  [dict removeValueForKey:@"bar"];
  XCTAssertEqual(dict.count, 3U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 200);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 202);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 203);

  [dict removeValueForKey:@"mumble"];
  XCTAssertEqual(dict.count, 2U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 200);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 202);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);

  [dict removeAll];
  XCTAssertEqual(dict.count, 0U);
  XCTAssertFalse([dict valueForKey:@"foo" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"baz" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);
  [dict release];
}

- (void)testInplaceMutation {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const int32_t kValues[] = { 200, 201, 202, 203 };
  GPBStringInt32Dictionary *dict =
      [[GPBStringInt32Dictionary alloc] initWithValues:kValues
                                        forKeys:kKeys
                                          count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 4U);
  int32_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 200);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 201);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 202);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 203);

  [dict setValue:203 forKey:@"foo"];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 203);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 201);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 202);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 203);

  [dict setValue:201 forKey:@"mumble"];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 203);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 201);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 202);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 201);

  const NSString *kKeys2[] = { @"bar", @"baz" };
  const int32_t kValues2[] = { 202, 200 };
  GPBStringInt32Dictionary *dict2 =
      [[GPBStringInt32Dictionary alloc] initWithValues:kValues2
                                               forKeys:kKeys2
                                                 count:GPBARRAYSIZE(kValues2)];
  XCTAssertNotNil(dict2);
  [dict addEntriesFromDictionary:dict2];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 203);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 202);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 200);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 201);

  [dict2 release];
  [dict release];
}

@end

#pragma mark - String -> UInt64

@interface GPBStringUInt64DictionaryTests : XCTestCase
@end

@implementation GPBStringUInt64DictionaryTests

- (void)testEmpty {
  GPBStringUInt64Dictionary *dict = [[GPBStringUInt64Dictionary alloc] init];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 0U);
  XCTAssertFalse([dict valueForKey:@"foo" value:NULL]);
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, uint64_t aValue, BOOL *stop) {
    #pragma unused(aKey, aValue, stop)
    XCTFail(@"Shouldn't get here!");
  }];
  [dict release];
}

- (void)testOne {
  GPBStringUInt64Dictionary *dict = [GPBStringUInt64Dictionary dictionaryWithValue:300U forKey:@"foo"];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 1U);
  uint64_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 300U);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, uint64_t aValue, BOOL *stop) {
    XCTAssertEqualObjects(aKey, @"foo");
    XCTAssertEqual(aValue, 300U);
    XCTAssertNotEqual(stop, NULL);
  }];
}

- (void)testBasics {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz" };
  const uint64_t kValues[] = { 300U, 301U, 302U };
  GPBStringUInt64Dictionary *dict =
      [[GPBStringUInt64Dictionary alloc] initWithValues:kValues
                                                forKeys:kKeys
                                                  count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 3U);
  uint64_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 300U);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 301U);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 302U);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);

  __block NSUInteger idx = 0;
  NSString **seenKeys = malloc(3 * sizeof(NSString*));
  uint64_t *seenValues = malloc(3 * sizeof(uint64_t));
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, uint64_t aValue, BOOL *stop) {
    XCTAssertLessThan(idx, 3U);
    seenKeys[idx] = aKey;
    seenValues[idx] = aValue;
    XCTAssertNotEqual(stop, NULL);
    ++idx;
  }];
  for (int i = 0; i < 3; ++i) {
    BOOL foundKey = NO;
    for (int j = 0; (j < 3) && !foundKey; ++j) {
      if ([kKeys[i] isEqual:seenKeys[j]]) {
        foundKey = YES;
        XCTAssertEqual(kValues[i], seenValues[j], @"i = %d, j = %d", i, j);
      }
    }
    XCTAssertTrue(foundKey, @"i = %d", i);
  }
  free(seenKeys);
  free(seenValues);

  // Stopping the enumeration.
  idx = 0;
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, uint64_t aValue, BOOL *stop) {
    #pragma unused(aKey, aValue)
    if (idx == 1) *stop = YES;
    XCTAssertNotEqual(idx, 2U);
    ++idx;
  }];
  [dict release];
}

- (void)testEquality {
  const NSString *kKeys1[] = { @"foo", @"bar", @"baz", @"mumble" };
  const NSString *kKeys2[] = { @"bar", @"foo", @"mumble" };
  const uint64_t kValues1[] = { 300U, 301U, 302U };
  const uint64_t kValues2[] = { 300U, 303U, 302U };
  const uint64_t kValues3[] = { 300U, 301U, 302U, 303U };
  GPBStringUInt64Dictionary *dict1 =
      [[GPBStringUInt64Dictionary alloc] initWithValues:kValues1
                                                forKeys:kKeys1
                                                  count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict1);
  GPBStringUInt64Dictionary *dict1prime =
      [[GPBStringUInt64Dictionary alloc] initWithValues:kValues1
                                                forKeys:kKeys1
                                                  count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict1prime);
  GPBStringUInt64Dictionary *dict2 =
      [[GPBStringUInt64Dictionary alloc] initWithValues:kValues2
                                                forKeys:kKeys1
                                                  count:GPBARRAYSIZE(kValues2)];
  XCTAssertNotNil(dict2);
  GPBStringUInt64Dictionary *dict3 =
      [[GPBStringUInt64Dictionary alloc] initWithValues:kValues1
                                                forKeys:kKeys2
                                                  count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict3);
  GPBStringUInt64Dictionary *dict4 =
      [[GPBStringUInt64Dictionary alloc] initWithValues:kValues3
                                                forKeys:kKeys1
                                                  count:GPBARRAYSIZE(kValues3)];
  XCTAssertNotNil(dict4);

  // 1/1Prime should be different objects, but equal.
  XCTAssertNotEqual(dict1, dict1prime);
  XCTAssertEqualObjects(dict1, dict1prime);
  // Equal, so they must have same hash.
  XCTAssertEqual([dict1 hash], [dict1prime hash]);

  // 2 is same keys, different values; not equal.
  XCTAssertNotEqualObjects(dict1, dict2);

  // 3 is different keys, same values; not equal.
  XCTAssertNotEqualObjects(dict1, dict3);

  // 4 extra pair; not equal
  XCTAssertNotEqualObjects(dict1, dict4);

  [dict1 release];
  [dict1prime release];
  [dict2 release];
  [dict3 release];
  [dict4 release];
}

- (void)testCopy {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const uint64_t kValues[] = { 300U, 301U, 302U, 303U };
  GPBStringUInt64Dictionary *dict =
      [[GPBStringUInt64Dictionary alloc] initWithValues:kValues
                                                forKeys:kKeys
                                                  count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);

  GPBStringUInt64Dictionary *dict2 = [dict copy];
  XCTAssertNotNil(dict2);

  // Should be new object but equal.
  XCTAssertNotEqual(dict, dict2);
  XCTAssertEqualObjects(dict, dict2);
  XCTAssertTrue([dict2 isKindOfClass:[GPBStringUInt64Dictionary class]]);

  [dict2 release];
  [dict release];
}

- (void)testDictionaryFromDictionary {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const uint64_t kValues[] = { 300U, 301U, 302U, 303U };
  GPBStringUInt64Dictionary *dict =
      [[GPBStringUInt64Dictionary alloc] initWithValues:kValues
                                                forKeys:kKeys
                                                  count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);

  GPBStringUInt64Dictionary *dict2 =
      [GPBStringUInt64Dictionary dictionaryWithDictionary:dict];
  XCTAssertNotNil(dict2);

  // Should be new pointer, but equal objects.
  XCTAssertNotEqual(dict, dict2);
  XCTAssertEqualObjects(dict, dict2);
  [dict release];
}

- (void)testAdds {
  GPBStringUInt64Dictionary *dict = [GPBStringUInt64Dictionary dictionary];
  XCTAssertNotNil(dict);

  XCTAssertEqual(dict.count, 0U);
  [dict setValue:300U forKey:@"foo"];
  XCTAssertEqual(dict.count, 1U);

  const NSString *kKeys[] = { @"bar", @"baz", @"mumble" };
  const uint64_t kValues[] = { 301U, 302U, 303U };
  GPBStringUInt64Dictionary *dict2 =
      [[GPBStringUInt64Dictionary alloc] initWithValues:kValues
                                                forKeys:kKeys
                                                  count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict2);
  [dict addEntriesFromDictionary:dict2];
  XCTAssertEqual(dict.count, 4U);

  uint64_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 300U);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 301U);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 302U);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 303U);
  [dict2 release];
}

- (void)testRemove {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const uint64_t kValues[] = { 300U, 301U, 302U, 303U };
  GPBStringUInt64Dictionary *dict =
      [[GPBStringUInt64Dictionary alloc] initWithValues:kValues
                                         forKeys:kKeys
                                           count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 4U);

  [dict removeValueForKey:@"bar"];
  XCTAssertEqual(dict.count, 3U);
  uint64_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 300U);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 302U);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 303U);

  // Remove again does nothing.
  [dict removeValueForKey:@"bar"];
  XCTAssertEqual(dict.count, 3U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 300U);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 302U);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 303U);

  [dict removeValueForKey:@"mumble"];
  XCTAssertEqual(dict.count, 2U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 300U);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 302U);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);

  [dict removeAll];
  XCTAssertEqual(dict.count, 0U);
  XCTAssertFalse([dict valueForKey:@"foo" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"baz" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);
  [dict release];
}

- (void)testInplaceMutation {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const uint64_t kValues[] = { 300U, 301U, 302U, 303U };
  GPBStringUInt64Dictionary *dict =
      [[GPBStringUInt64Dictionary alloc] initWithValues:kValues
                                         forKeys:kKeys
                                           count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 4U);
  uint64_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 300U);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 301U);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 302U);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 303U);

  [dict setValue:303U forKey:@"foo"];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 303U);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 301U);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 302U);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 303U);

  [dict setValue:301U forKey:@"mumble"];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 303U);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 301U);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 302U);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 301U);

  const NSString *kKeys2[] = { @"bar", @"baz" };
  const uint64_t kValues2[] = { 302U, 300U };
  GPBStringUInt64Dictionary *dict2 =
      [[GPBStringUInt64Dictionary alloc] initWithValues:kValues2
                                                forKeys:kKeys2
                                                  count:GPBARRAYSIZE(kValues2)];
  XCTAssertNotNil(dict2);
  [dict addEntriesFromDictionary:dict2];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 303U);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 302U);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 300U);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 301U);

  [dict2 release];
  [dict release];
}

@end

#pragma mark - String -> Int64

@interface GPBStringInt64DictionaryTests : XCTestCase
@end

@implementation GPBStringInt64DictionaryTests

- (void)testEmpty {
  GPBStringInt64Dictionary *dict = [[GPBStringInt64Dictionary alloc] init];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 0U);
  XCTAssertFalse([dict valueForKey:@"foo" value:NULL]);
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, int64_t aValue, BOOL *stop) {
    #pragma unused(aKey, aValue, stop)
    XCTFail(@"Shouldn't get here!");
  }];
  [dict release];
}

- (void)testOne {
  GPBStringInt64Dictionary *dict = [GPBStringInt64Dictionary dictionaryWithValue:400 forKey:@"foo"];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 1U);
  int64_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 400);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, int64_t aValue, BOOL *stop) {
    XCTAssertEqualObjects(aKey, @"foo");
    XCTAssertEqual(aValue, 400);
    XCTAssertNotEqual(stop, NULL);
  }];
}

- (void)testBasics {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz" };
  const int64_t kValues[] = { 400, 401, 402 };
  GPBStringInt64Dictionary *dict =
      [[GPBStringInt64Dictionary alloc] initWithValues:kValues
                                               forKeys:kKeys
                                                 count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 3U);
  int64_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 400);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 401);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 402);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);

  __block NSUInteger idx = 0;
  NSString **seenKeys = malloc(3 * sizeof(NSString*));
  int64_t *seenValues = malloc(3 * sizeof(int64_t));
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, int64_t aValue, BOOL *stop) {
    XCTAssertLessThan(idx, 3U);
    seenKeys[idx] = aKey;
    seenValues[idx] = aValue;
    XCTAssertNotEqual(stop, NULL);
    ++idx;
  }];
  for (int i = 0; i < 3; ++i) {
    BOOL foundKey = NO;
    for (int j = 0; (j < 3) && !foundKey; ++j) {
      if ([kKeys[i] isEqual:seenKeys[j]]) {
        foundKey = YES;
        XCTAssertEqual(kValues[i], seenValues[j], @"i = %d, j = %d", i, j);
      }
    }
    XCTAssertTrue(foundKey, @"i = %d", i);
  }
  free(seenKeys);
  free(seenValues);

  // Stopping the enumeration.
  idx = 0;
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, int64_t aValue, BOOL *stop) {
    #pragma unused(aKey, aValue)
    if (idx == 1) *stop = YES;
    XCTAssertNotEqual(idx, 2U);
    ++idx;
  }];
  [dict release];
}

- (void)testEquality {
  const NSString *kKeys1[] = { @"foo", @"bar", @"baz", @"mumble" };
  const NSString *kKeys2[] = { @"bar", @"foo", @"mumble" };
  const int64_t kValues1[] = { 400, 401, 402 };
  const int64_t kValues2[] = { 400, 403, 402 };
  const int64_t kValues3[] = { 400, 401, 402, 403 };
  GPBStringInt64Dictionary *dict1 =
      [[GPBStringInt64Dictionary alloc] initWithValues:kValues1
                                               forKeys:kKeys1
                                                 count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict1);
  GPBStringInt64Dictionary *dict1prime =
      [[GPBStringInt64Dictionary alloc] initWithValues:kValues1
                                               forKeys:kKeys1
                                                 count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict1prime);
  GPBStringInt64Dictionary *dict2 =
      [[GPBStringInt64Dictionary alloc] initWithValues:kValues2
                                               forKeys:kKeys1
                                                 count:GPBARRAYSIZE(kValues2)];
  XCTAssertNotNil(dict2);
  GPBStringInt64Dictionary *dict3 =
      [[GPBStringInt64Dictionary alloc] initWithValues:kValues1
                                               forKeys:kKeys2
                                                 count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict3);
  GPBStringInt64Dictionary *dict4 =
      [[GPBStringInt64Dictionary alloc] initWithValues:kValues3
                                               forKeys:kKeys1
                                                 count:GPBARRAYSIZE(kValues3)];
  XCTAssertNotNil(dict4);

  // 1/1Prime should be different objects, but equal.
  XCTAssertNotEqual(dict1, dict1prime);
  XCTAssertEqualObjects(dict1, dict1prime);
  // Equal, so they must have same hash.
  XCTAssertEqual([dict1 hash], [dict1prime hash]);

  // 2 is same keys, different values; not equal.
  XCTAssertNotEqualObjects(dict1, dict2);

  // 3 is different keys, same values; not equal.
  XCTAssertNotEqualObjects(dict1, dict3);

  // 4 extra pair; not equal
  XCTAssertNotEqualObjects(dict1, dict4);

  [dict1 release];
  [dict1prime release];
  [dict2 release];
  [dict3 release];
  [dict4 release];
}

- (void)testCopy {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const int64_t kValues[] = { 400, 401, 402, 403 };
  GPBStringInt64Dictionary *dict =
      [[GPBStringInt64Dictionary alloc] initWithValues:kValues
                                               forKeys:kKeys
                                                 count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);

  GPBStringInt64Dictionary *dict2 = [dict copy];
  XCTAssertNotNil(dict2);

  // Should be new object but equal.
  XCTAssertNotEqual(dict, dict2);
  XCTAssertEqualObjects(dict, dict2);
  XCTAssertTrue([dict2 isKindOfClass:[GPBStringInt64Dictionary class]]);

  [dict2 release];
  [dict release];
}

- (void)testDictionaryFromDictionary {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const int64_t kValues[] = { 400, 401, 402, 403 };
  GPBStringInt64Dictionary *dict =
      [[GPBStringInt64Dictionary alloc] initWithValues:kValues
                                               forKeys:kKeys
                                                 count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);

  GPBStringInt64Dictionary *dict2 =
      [GPBStringInt64Dictionary dictionaryWithDictionary:dict];
  XCTAssertNotNil(dict2);

  // Should be new pointer, but equal objects.
  XCTAssertNotEqual(dict, dict2);
  XCTAssertEqualObjects(dict, dict2);
  [dict release];
}

- (void)testAdds {
  GPBStringInt64Dictionary *dict = [GPBStringInt64Dictionary dictionary];
  XCTAssertNotNil(dict);

  XCTAssertEqual(dict.count, 0U);
  [dict setValue:400 forKey:@"foo"];
  XCTAssertEqual(dict.count, 1U);

  const NSString *kKeys[] = { @"bar", @"baz", @"mumble" };
  const int64_t kValues[] = { 401, 402, 403 };
  GPBStringInt64Dictionary *dict2 =
      [[GPBStringInt64Dictionary alloc] initWithValues:kValues
                                               forKeys:kKeys
                                                 count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict2);
  [dict addEntriesFromDictionary:dict2];
  XCTAssertEqual(dict.count, 4U);

  int64_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 400);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 401);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 402);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 403);
  [dict2 release];
}

- (void)testRemove {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const int64_t kValues[] = { 400, 401, 402, 403 };
  GPBStringInt64Dictionary *dict =
      [[GPBStringInt64Dictionary alloc] initWithValues:kValues
                                        forKeys:kKeys
                                          count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 4U);

  [dict removeValueForKey:@"bar"];
  XCTAssertEqual(dict.count, 3U);
  int64_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 400);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 402);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 403);

  // Remove again does nothing.
  [dict removeValueForKey:@"bar"];
  XCTAssertEqual(dict.count, 3U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 400);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 402);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 403);

  [dict removeValueForKey:@"mumble"];
  XCTAssertEqual(dict.count, 2U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 400);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 402);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);

  [dict removeAll];
  XCTAssertEqual(dict.count, 0U);
  XCTAssertFalse([dict valueForKey:@"foo" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"baz" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);
  [dict release];
}

- (void)testInplaceMutation {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const int64_t kValues[] = { 400, 401, 402, 403 };
  GPBStringInt64Dictionary *dict =
      [[GPBStringInt64Dictionary alloc] initWithValues:kValues
                                        forKeys:kKeys
                                          count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 4U);
  int64_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 400);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 401);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 402);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 403);

  [dict setValue:403 forKey:@"foo"];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 403);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 401);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 402);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 403);

  [dict setValue:401 forKey:@"mumble"];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 403);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 401);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 402);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 401);

  const NSString *kKeys2[] = { @"bar", @"baz" };
  const int64_t kValues2[] = { 402, 400 };
  GPBStringInt64Dictionary *dict2 =
      [[GPBStringInt64Dictionary alloc] initWithValues:kValues2
                                               forKeys:kKeys2
                                                 count:GPBARRAYSIZE(kValues2)];
  XCTAssertNotNil(dict2);
  [dict addEntriesFromDictionary:dict2];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 403);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 402);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 400);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 401);

  [dict2 release];
  [dict release];
}

@end

#pragma mark - String -> Bool

@interface GPBStringBoolDictionaryTests : XCTestCase
@end

@implementation GPBStringBoolDictionaryTests

- (void)testEmpty {
  GPBStringBoolDictionary *dict = [[GPBStringBoolDictionary alloc] init];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 0U);
  XCTAssertFalse([dict valueForKey:@"foo" value:NULL]);
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, BOOL aValue, BOOL *stop) {
    #pragma unused(aKey, aValue, stop)
    XCTFail(@"Shouldn't get here!");
  }];
  [dict release];
}

- (void)testOne {
  GPBStringBoolDictionary *dict = [GPBStringBoolDictionary dictionaryWithValue:YES forKey:@"foo"];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 1U);
  BOOL value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, YES);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, BOOL aValue, BOOL *stop) {
    XCTAssertEqualObjects(aKey, @"foo");
    XCTAssertEqual(aValue, YES);
    XCTAssertNotEqual(stop, NULL);
  }];
}

- (void)testBasics {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz" };
  const BOOL kValues[] = { YES, YES, NO };
  GPBStringBoolDictionary *dict =
      [[GPBStringBoolDictionary alloc] initWithValues:kValues
                                              forKeys:kKeys
                                                count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 3U);
  BOOL value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, YES);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, YES);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, NO);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);

  __block NSUInteger idx = 0;
  NSString **seenKeys = malloc(3 * sizeof(NSString*));
  BOOL *seenValues = malloc(3 * sizeof(BOOL));
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, BOOL aValue, BOOL *stop) {
    XCTAssertLessThan(idx, 3U);
    seenKeys[idx] = aKey;
    seenValues[idx] = aValue;
    XCTAssertNotEqual(stop, NULL);
    ++idx;
  }];
  for (int i = 0; i < 3; ++i) {
    BOOL foundKey = NO;
    for (int j = 0; (j < 3) && !foundKey; ++j) {
      if ([kKeys[i] isEqual:seenKeys[j]]) {
        foundKey = YES;
        XCTAssertEqual(kValues[i], seenValues[j], @"i = %d, j = %d", i, j);
      }
    }
    XCTAssertTrue(foundKey, @"i = %d", i);
  }
  free(seenKeys);
  free(seenValues);

  // Stopping the enumeration.
  idx = 0;
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, BOOL aValue, BOOL *stop) {
    #pragma unused(aKey, aValue)
    if (idx == 1) *stop = YES;
    XCTAssertNotEqual(idx, 2U);
    ++idx;
  }];
  [dict release];
}

- (void)testEquality {
  const NSString *kKeys1[] = { @"foo", @"bar", @"baz", @"mumble" };
  const NSString *kKeys2[] = { @"bar", @"foo", @"mumble" };
  const BOOL kValues1[] = { YES, YES, NO };
  const BOOL kValues2[] = { YES, NO, NO };
  const BOOL kValues3[] = { YES, YES, NO, NO };
  GPBStringBoolDictionary *dict1 =
      [[GPBStringBoolDictionary alloc] initWithValues:kValues1
                                              forKeys:kKeys1
                                                count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict1);
  GPBStringBoolDictionary *dict1prime =
      [[GPBStringBoolDictionary alloc] initWithValues:kValues1
                                              forKeys:kKeys1
                                                count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict1prime);
  GPBStringBoolDictionary *dict2 =
      [[GPBStringBoolDictionary alloc] initWithValues:kValues2
                                              forKeys:kKeys1
                                                count:GPBARRAYSIZE(kValues2)];
  XCTAssertNotNil(dict2);
  GPBStringBoolDictionary *dict3 =
      [[GPBStringBoolDictionary alloc] initWithValues:kValues1
                                              forKeys:kKeys2
                                                count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict3);
  GPBStringBoolDictionary *dict4 =
      [[GPBStringBoolDictionary alloc] initWithValues:kValues3
                                              forKeys:kKeys1
                                                count:GPBARRAYSIZE(kValues3)];
  XCTAssertNotNil(dict4);

  // 1/1Prime should be different objects, but equal.
  XCTAssertNotEqual(dict1, dict1prime);
  XCTAssertEqualObjects(dict1, dict1prime);
  // Equal, so they must have same hash.
  XCTAssertEqual([dict1 hash], [dict1prime hash]);

  // 2 is same keys, different values; not equal.
  XCTAssertNotEqualObjects(dict1, dict2);

  // 3 is different keys, same values; not equal.
  XCTAssertNotEqualObjects(dict1, dict3);

  // 4 extra pair; not equal
  XCTAssertNotEqualObjects(dict1, dict4);

  [dict1 release];
  [dict1prime release];
  [dict2 release];
  [dict3 release];
  [dict4 release];
}

- (void)testCopy {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const BOOL kValues[] = { YES, YES, NO, NO };
  GPBStringBoolDictionary *dict =
      [[GPBStringBoolDictionary alloc] initWithValues:kValues
                                              forKeys:kKeys
                                                count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);

  GPBStringBoolDictionary *dict2 = [dict copy];
  XCTAssertNotNil(dict2);

  // Should be new object but equal.
  XCTAssertNotEqual(dict, dict2);
  XCTAssertEqualObjects(dict, dict2);
  XCTAssertTrue([dict2 isKindOfClass:[GPBStringBoolDictionary class]]);

  [dict2 release];
  [dict release];
}

- (void)testDictionaryFromDictionary {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const BOOL kValues[] = { YES, YES, NO, NO };
  GPBStringBoolDictionary *dict =
      [[GPBStringBoolDictionary alloc] initWithValues:kValues
                                              forKeys:kKeys
                                                count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);

  GPBStringBoolDictionary *dict2 =
      [GPBStringBoolDictionary dictionaryWithDictionary:dict];
  XCTAssertNotNil(dict2);

  // Should be new pointer, but equal objects.
  XCTAssertNotEqual(dict, dict2);
  XCTAssertEqualObjects(dict, dict2);
  [dict release];
}

- (void)testAdds {
  GPBStringBoolDictionary *dict = [GPBStringBoolDictionary dictionary];
  XCTAssertNotNil(dict);

  XCTAssertEqual(dict.count, 0U);
  [dict setValue:YES forKey:@"foo"];
  XCTAssertEqual(dict.count, 1U);

  const NSString *kKeys[] = { @"bar", @"baz", @"mumble" };
  const BOOL kValues[] = { YES, NO, NO };
  GPBStringBoolDictionary *dict2 =
      [[GPBStringBoolDictionary alloc] initWithValues:kValues
                                              forKeys:kKeys
                                                count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict2);
  [dict addEntriesFromDictionary:dict2];
  XCTAssertEqual(dict.count, 4U);

  BOOL value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, YES);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, YES);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, NO);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, NO);
  [dict2 release];
}

- (void)testRemove {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const BOOL kValues[] = { YES, YES, NO, NO };
  GPBStringBoolDictionary *dict =
      [[GPBStringBoolDictionary alloc] initWithValues:kValues
                                       forKeys:kKeys
                                         count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 4U);

  [dict removeValueForKey:@"bar"];
  XCTAssertEqual(dict.count, 3U);
  BOOL value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, YES);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, NO);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, NO);

  // Remove again does nothing.
  [dict removeValueForKey:@"bar"];
  XCTAssertEqual(dict.count, 3U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, YES);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, NO);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, NO);

  [dict removeValueForKey:@"mumble"];
  XCTAssertEqual(dict.count, 2U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, YES);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, NO);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);

  [dict removeAll];
  XCTAssertEqual(dict.count, 0U);
  XCTAssertFalse([dict valueForKey:@"foo" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"baz" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);
  [dict release];
}

- (void)testInplaceMutation {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const BOOL kValues[] = { YES, YES, NO, NO };
  GPBStringBoolDictionary *dict =
      [[GPBStringBoolDictionary alloc] initWithValues:kValues
                                       forKeys:kKeys
                                         count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 4U);
  BOOL value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, YES);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, YES);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, NO);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, NO);

  [dict setValue:NO forKey:@"foo"];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, NO);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, YES);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, NO);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, NO);

  [dict setValue:YES forKey:@"mumble"];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, NO);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, YES);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, NO);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, YES);

  const NSString *kKeys2[] = { @"bar", @"baz" };
  const BOOL kValues2[] = { NO, YES };
  GPBStringBoolDictionary *dict2 =
      [[GPBStringBoolDictionary alloc] initWithValues:kValues2
                                              forKeys:kKeys2
                                                count:GPBARRAYSIZE(kValues2)];
  XCTAssertNotNil(dict2);
  [dict addEntriesFromDictionary:dict2];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, NO);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, NO);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, YES);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, YES);

  [dict2 release];
  [dict release];
}

@end

#pragma mark - String -> Float

@interface GPBStringFloatDictionaryTests : XCTestCase
@end

@implementation GPBStringFloatDictionaryTests

- (void)testEmpty {
  GPBStringFloatDictionary *dict = [[GPBStringFloatDictionary alloc] init];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 0U);
  XCTAssertFalse([dict valueForKey:@"foo" value:NULL]);
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, float aValue, BOOL *stop) {
    #pragma unused(aKey, aValue, stop)
    XCTFail(@"Shouldn't get here!");
  }];
  [dict release];
}

- (void)testOne {
  GPBStringFloatDictionary *dict = [GPBStringFloatDictionary dictionaryWithValue:500.f forKey:@"foo"];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 1U);
  float value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 500.f);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, float aValue, BOOL *stop) {
    XCTAssertEqualObjects(aKey, @"foo");
    XCTAssertEqual(aValue, 500.f);
    XCTAssertNotEqual(stop, NULL);
  }];
}

- (void)testBasics {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz" };
  const float kValues[] = { 500.f, 501.f, 502.f };
  GPBStringFloatDictionary *dict =
      [[GPBStringFloatDictionary alloc] initWithValues:kValues
                                               forKeys:kKeys
                                                 count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 3U);
  float value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 500.f);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 501.f);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 502.f);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);

  __block NSUInteger idx = 0;
  NSString **seenKeys = malloc(3 * sizeof(NSString*));
  float *seenValues = malloc(3 * sizeof(float));
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, float aValue, BOOL *stop) {
    XCTAssertLessThan(idx, 3U);
    seenKeys[idx] = aKey;
    seenValues[idx] = aValue;
    XCTAssertNotEqual(stop, NULL);
    ++idx;
  }];
  for (int i = 0; i < 3; ++i) {
    BOOL foundKey = NO;
    for (int j = 0; (j < 3) && !foundKey; ++j) {
      if ([kKeys[i] isEqual:seenKeys[j]]) {
        foundKey = YES;
        XCTAssertEqual(kValues[i], seenValues[j], @"i = %d, j = %d", i, j);
      }
    }
    XCTAssertTrue(foundKey, @"i = %d", i);
  }
  free(seenKeys);
  free(seenValues);

  // Stopping the enumeration.
  idx = 0;
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, float aValue, BOOL *stop) {
    #pragma unused(aKey, aValue)
    if (idx == 1) *stop = YES;
    XCTAssertNotEqual(idx, 2U);
    ++idx;
  }];
  [dict release];
}

- (void)testEquality {
  const NSString *kKeys1[] = { @"foo", @"bar", @"baz", @"mumble" };
  const NSString *kKeys2[] = { @"bar", @"foo", @"mumble" };
  const float kValues1[] = { 500.f, 501.f, 502.f };
  const float kValues2[] = { 500.f, 503.f, 502.f };
  const float kValues3[] = { 500.f, 501.f, 502.f, 503.f };
  GPBStringFloatDictionary *dict1 =
      [[GPBStringFloatDictionary alloc] initWithValues:kValues1
                                               forKeys:kKeys1
                                                 count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict1);
  GPBStringFloatDictionary *dict1prime =
      [[GPBStringFloatDictionary alloc] initWithValues:kValues1
                                               forKeys:kKeys1
                                                 count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict1prime);
  GPBStringFloatDictionary *dict2 =
      [[GPBStringFloatDictionary alloc] initWithValues:kValues2
                                               forKeys:kKeys1
                                                 count:GPBARRAYSIZE(kValues2)];
  XCTAssertNotNil(dict2);
  GPBStringFloatDictionary *dict3 =
      [[GPBStringFloatDictionary alloc] initWithValues:kValues1
                                               forKeys:kKeys2
                                                 count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict3);
  GPBStringFloatDictionary *dict4 =
      [[GPBStringFloatDictionary alloc] initWithValues:kValues3
                                               forKeys:kKeys1
                                                 count:GPBARRAYSIZE(kValues3)];
  XCTAssertNotNil(dict4);

  // 1/1Prime should be different objects, but equal.
  XCTAssertNotEqual(dict1, dict1prime);
  XCTAssertEqualObjects(dict1, dict1prime);
  // Equal, so they must have same hash.
  XCTAssertEqual([dict1 hash], [dict1prime hash]);

  // 2 is same keys, different values; not equal.
  XCTAssertNotEqualObjects(dict1, dict2);

  // 3 is different keys, same values; not equal.
  XCTAssertNotEqualObjects(dict1, dict3);

  // 4 extra pair; not equal
  XCTAssertNotEqualObjects(dict1, dict4);

  [dict1 release];
  [dict1prime release];
  [dict2 release];
  [dict3 release];
  [dict4 release];
}

- (void)testCopy {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const float kValues[] = { 500.f, 501.f, 502.f, 503.f };
  GPBStringFloatDictionary *dict =
      [[GPBStringFloatDictionary alloc] initWithValues:kValues
                                               forKeys:kKeys
                                                 count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);

  GPBStringFloatDictionary *dict2 = [dict copy];
  XCTAssertNotNil(dict2);

  // Should be new object but equal.
  XCTAssertNotEqual(dict, dict2);
  XCTAssertEqualObjects(dict, dict2);
  XCTAssertTrue([dict2 isKindOfClass:[GPBStringFloatDictionary class]]);

  [dict2 release];
  [dict release];
}

- (void)testDictionaryFromDictionary {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const float kValues[] = { 500.f, 501.f, 502.f, 503.f };
  GPBStringFloatDictionary *dict =
      [[GPBStringFloatDictionary alloc] initWithValues:kValues
                                               forKeys:kKeys
                                                 count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);

  GPBStringFloatDictionary *dict2 =
      [GPBStringFloatDictionary dictionaryWithDictionary:dict];
  XCTAssertNotNil(dict2);

  // Should be new pointer, but equal objects.
  XCTAssertNotEqual(dict, dict2);
  XCTAssertEqualObjects(dict, dict2);
  [dict release];
}

- (void)testAdds {
  GPBStringFloatDictionary *dict = [GPBStringFloatDictionary dictionary];
  XCTAssertNotNil(dict);

  XCTAssertEqual(dict.count, 0U);
  [dict setValue:500.f forKey:@"foo"];
  XCTAssertEqual(dict.count, 1U);

  const NSString *kKeys[] = { @"bar", @"baz", @"mumble" };
  const float kValues[] = { 501.f, 502.f, 503.f };
  GPBStringFloatDictionary *dict2 =
      [[GPBStringFloatDictionary alloc] initWithValues:kValues
                                               forKeys:kKeys
                                                 count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict2);
  [dict addEntriesFromDictionary:dict2];
  XCTAssertEqual(dict.count, 4U);

  float value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 500.f);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 501.f);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 502.f);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 503.f);
  [dict2 release];
}

- (void)testRemove {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const float kValues[] = { 500.f, 501.f, 502.f, 503.f };
  GPBStringFloatDictionary *dict =
      [[GPBStringFloatDictionary alloc] initWithValues:kValues
                                        forKeys:kKeys
                                          count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 4U);

  [dict removeValueForKey:@"bar"];
  XCTAssertEqual(dict.count, 3U);
  float value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 500.f);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 502.f);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 503.f);

  // Remove again does nothing.
  [dict removeValueForKey:@"bar"];
  XCTAssertEqual(dict.count, 3U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 500.f);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 502.f);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 503.f);

  [dict removeValueForKey:@"mumble"];
  XCTAssertEqual(dict.count, 2U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 500.f);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 502.f);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);

  [dict removeAll];
  XCTAssertEqual(dict.count, 0U);
  XCTAssertFalse([dict valueForKey:@"foo" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"baz" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);
  [dict release];
}

- (void)testInplaceMutation {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const float kValues[] = { 500.f, 501.f, 502.f, 503.f };
  GPBStringFloatDictionary *dict =
      [[GPBStringFloatDictionary alloc] initWithValues:kValues
                                        forKeys:kKeys
                                          count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 4U);
  float value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 500.f);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 501.f);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 502.f);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 503.f);

  [dict setValue:503.f forKey:@"foo"];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 503.f);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 501.f);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 502.f);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 503.f);

  [dict setValue:501.f forKey:@"mumble"];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 503.f);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 501.f);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 502.f);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 501.f);

  const NSString *kKeys2[] = { @"bar", @"baz" };
  const float kValues2[] = { 502.f, 500.f };
  GPBStringFloatDictionary *dict2 =
      [[GPBStringFloatDictionary alloc] initWithValues:kValues2
                                               forKeys:kKeys2
                                                 count:GPBARRAYSIZE(kValues2)];
  XCTAssertNotNil(dict2);
  [dict addEntriesFromDictionary:dict2];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 503.f);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 502.f);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 500.f);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 501.f);

  [dict2 release];
  [dict release];
}

@end

#pragma mark - String -> Double

@interface GPBStringDoubleDictionaryTests : XCTestCase
@end

@implementation GPBStringDoubleDictionaryTests

- (void)testEmpty {
  GPBStringDoubleDictionary *dict = [[GPBStringDoubleDictionary alloc] init];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 0U);
  XCTAssertFalse([dict valueForKey:@"foo" value:NULL]);
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, double aValue, BOOL *stop) {
    #pragma unused(aKey, aValue, stop)
    XCTFail(@"Shouldn't get here!");
  }];
  [dict release];
}

- (void)testOne {
  GPBStringDoubleDictionary *dict = [GPBStringDoubleDictionary dictionaryWithValue:600. forKey:@"foo"];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 1U);
  double value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 600.);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, double aValue, BOOL *stop) {
    XCTAssertEqualObjects(aKey, @"foo");
    XCTAssertEqual(aValue, 600.);
    XCTAssertNotEqual(stop, NULL);
  }];
}

- (void)testBasics {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz" };
  const double kValues[] = { 600., 601., 602. };
  GPBStringDoubleDictionary *dict =
      [[GPBStringDoubleDictionary alloc] initWithValues:kValues
                                                forKeys:kKeys
                                                  count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 3U);
  double value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 600.);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 601.);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 602.);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);

  __block NSUInteger idx = 0;
  NSString **seenKeys = malloc(3 * sizeof(NSString*));
  double *seenValues = malloc(3 * sizeof(double));
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, double aValue, BOOL *stop) {
    XCTAssertLessThan(idx, 3U);
    seenKeys[idx] = aKey;
    seenValues[idx] = aValue;
    XCTAssertNotEqual(stop, NULL);
    ++idx;
  }];
  for (int i = 0; i < 3; ++i) {
    BOOL foundKey = NO;
    for (int j = 0; (j < 3) && !foundKey; ++j) {
      if ([kKeys[i] isEqual:seenKeys[j]]) {
        foundKey = YES;
        XCTAssertEqual(kValues[i], seenValues[j], @"i = %d, j = %d", i, j);
      }
    }
    XCTAssertTrue(foundKey, @"i = %d", i);
  }
  free(seenKeys);
  free(seenValues);

  // Stopping the enumeration.
  idx = 0;
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, double aValue, BOOL *stop) {
    #pragma unused(aKey, aValue)
    if (idx == 1) *stop = YES;
    XCTAssertNotEqual(idx, 2U);
    ++idx;
  }];
  [dict release];
}

- (void)testEquality {
  const NSString *kKeys1[] = { @"foo", @"bar", @"baz", @"mumble" };
  const NSString *kKeys2[] = { @"bar", @"foo", @"mumble" };
  const double kValues1[] = { 600., 601., 602. };
  const double kValues2[] = { 600., 603., 602. };
  const double kValues3[] = { 600., 601., 602., 603. };
  GPBStringDoubleDictionary *dict1 =
      [[GPBStringDoubleDictionary alloc] initWithValues:kValues1
                                                forKeys:kKeys1
                                                  count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict1);
  GPBStringDoubleDictionary *dict1prime =
      [[GPBStringDoubleDictionary alloc] initWithValues:kValues1
                                                forKeys:kKeys1
                                                  count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict1prime);
  GPBStringDoubleDictionary *dict2 =
      [[GPBStringDoubleDictionary alloc] initWithValues:kValues2
                                                forKeys:kKeys1
                                                  count:GPBARRAYSIZE(kValues2)];
  XCTAssertNotNil(dict2);
  GPBStringDoubleDictionary *dict3 =
      [[GPBStringDoubleDictionary alloc] initWithValues:kValues1
                                                forKeys:kKeys2
                                                  count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict3);
  GPBStringDoubleDictionary *dict4 =
      [[GPBStringDoubleDictionary alloc] initWithValues:kValues3
                                                forKeys:kKeys1
                                                  count:GPBARRAYSIZE(kValues3)];
  XCTAssertNotNil(dict4);

  // 1/1Prime should be different objects, but equal.
  XCTAssertNotEqual(dict1, dict1prime);
  XCTAssertEqualObjects(dict1, dict1prime);
  // Equal, so they must have same hash.
  XCTAssertEqual([dict1 hash], [dict1prime hash]);

  // 2 is same keys, different values; not equal.
  XCTAssertNotEqualObjects(dict1, dict2);

  // 3 is different keys, same values; not equal.
  XCTAssertNotEqualObjects(dict1, dict3);

  // 4 extra pair; not equal
  XCTAssertNotEqualObjects(dict1, dict4);

  [dict1 release];
  [dict1prime release];
  [dict2 release];
  [dict3 release];
  [dict4 release];
}

- (void)testCopy {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const double kValues[] = { 600., 601., 602., 603. };
  GPBStringDoubleDictionary *dict =
      [[GPBStringDoubleDictionary alloc] initWithValues:kValues
                                                forKeys:kKeys
                                                  count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);

  GPBStringDoubleDictionary *dict2 = [dict copy];
  XCTAssertNotNil(dict2);

  // Should be new object but equal.
  XCTAssertNotEqual(dict, dict2);
  XCTAssertEqualObjects(dict, dict2);
  XCTAssertTrue([dict2 isKindOfClass:[GPBStringDoubleDictionary class]]);

  [dict2 release];
  [dict release];
}

- (void)testDictionaryFromDictionary {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const double kValues[] = { 600., 601., 602., 603. };
  GPBStringDoubleDictionary *dict =
      [[GPBStringDoubleDictionary alloc] initWithValues:kValues
                                                forKeys:kKeys
                                                  count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);

  GPBStringDoubleDictionary *dict2 =
      [GPBStringDoubleDictionary dictionaryWithDictionary:dict];
  XCTAssertNotNil(dict2);

  // Should be new pointer, but equal objects.
  XCTAssertNotEqual(dict, dict2);
  XCTAssertEqualObjects(dict, dict2);
  [dict release];
}

- (void)testAdds {
  GPBStringDoubleDictionary *dict = [GPBStringDoubleDictionary dictionary];
  XCTAssertNotNil(dict);

  XCTAssertEqual(dict.count, 0U);
  [dict setValue:600. forKey:@"foo"];
  XCTAssertEqual(dict.count, 1U);

  const NSString *kKeys[] = { @"bar", @"baz", @"mumble" };
  const double kValues[] = { 601., 602., 603. };
  GPBStringDoubleDictionary *dict2 =
      [[GPBStringDoubleDictionary alloc] initWithValues:kValues
                                                forKeys:kKeys
                                                  count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict2);
  [dict addEntriesFromDictionary:dict2];
  XCTAssertEqual(dict.count, 4U);

  double value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 600.);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 601.);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 602.);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 603.);
  [dict2 release];
}

- (void)testRemove {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const double kValues[] = { 600., 601., 602., 603. };
  GPBStringDoubleDictionary *dict =
      [[GPBStringDoubleDictionary alloc] initWithValues:kValues
                                         forKeys:kKeys
                                           count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 4U);

  [dict removeValueForKey:@"bar"];
  XCTAssertEqual(dict.count, 3U);
  double value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 600.);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 602.);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 603.);

  // Remove again does nothing.
  [dict removeValueForKey:@"bar"];
  XCTAssertEqual(dict.count, 3U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 600.);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 602.);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 603.);

  [dict removeValueForKey:@"mumble"];
  XCTAssertEqual(dict.count, 2U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 600.);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 602.);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);

  [dict removeAll];
  XCTAssertEqual(dict.count, 0U);
  XCTAssertFalse([dict valueForKey:@"foo" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"baz" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);
  [dict release];
}

- (void)testInplaceMutation {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const double kValues[] = { 600., 601., 602., 603. };
  GPBStringDoubleDictionary *dict =
      [[GPBStringDoubleDictionary alloc] initWithValues:kValues
                                         forKeys:kKeys
                                           count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 4U);
  double value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 600.);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 601.);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 602.);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 603.);

  [dict setValue:603. forKey:@"foo"];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 603.);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 601.);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 602.);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 603.);

  [dict setValue:601. forKey:@"mumble"];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 603.);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 601.);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 602.);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 601.);

  const NSString *kKeys2[] = { @"bar", @"baz" };
  const double kValues2[] = { 602., 600. };
  GPBStringDoubleDictionary *dict2 =
      [[GPBStringDoubleDictionary alloc] initWithValues:kValues2
                                                forKeys:kKeys2
                                                  count:GPBARRAYSIZE(kValues2)];
  XCTAssertNotNil(dict2);
  [dict addEntriesFromDictionary:dict2];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 603.);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 602.);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 600.);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 601.);

  [dict2 release];
  [dict release];
}

@end

#pragma mark - String -> Enum

@interface GPBStringEnumDictionaryTests : XCTestCase
@end

@implementation GPBStringEnumDictionaryTests

- (void)testEmpty {
  GPBStringEnumDictionary *dict = [[GPBStringEnumDictionary alloc] init];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 0U);
  XCTAssertFalse([dict valueForKey:@"foo" value:NULL]);
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, int32_t aValue, BOOL *stop) {
    #pragma unused(aKey, aValue, stop)
    XCTFail(@"Shouldn't get here!");
  }];
  [dict release];
}

- (void)testOne {
  GPBStringEnumDictionary *dict = [GPBStringEnumDictionary dictionaryWithValue:700 forKey:@"foo"];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 1U);
  int32_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 700);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, int32_t aValue, BOOL *stop) {
    XCTAssertEqualObjects(aKey, @"foo");
    XCTAssertEqual(aValue, 700);
    XCTAssertNotEqual(stop, NULL);
  }];
}

- (void)testBasics {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz" };
  const int32_t kValues[] = { 700, 701, 702 };
  GPBStringEnumDictionary *dict =
      [[GPBStringEnumDictionary alloc] initWithValues:kValues
                                              forKeys:kKeys
                                                count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 3U);
  int32_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 700);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 701);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 702);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);

  __block NSUInteger idx = 0;
  NSString **seenKeys = malloc(3 * sizeof(NSString*));
  int32_t *seenValues = malloc(3 * sizeof(int32_t));
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, int32_t aValue, BOOL *stop) {
    XCTAssertLessThan(idx, 3U);
    seenKeys[idx] = aKey;
    seenValues[idx] = aValue;
    XCTAssertNotEqual(stop, NULL);
    ++idx;
  }];
  for (int i = 0; i < 3; ++i) {
    BOOL foundKey = NO;
    for (int j = 0; (j < 3) && !foundKey; ++j) {
      if ([kKeys[i] isEqual:seenKeys[j]]) {
        foundKey = YES;
        XCTAssertEqual(kValues[i], seenValues[j], @"i = %d, j = %d", i, j);
      }
    }
    XCTAssertTrue(foundKey, @"i = %d", i);
  }
  free(seenKeys);
  free(seenValues);

  // Stopping the enumeration.
  idx = 0;
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, int32_t aValue, BOOL *stop) {
    #pragma unused(aKey, aValue)
    if (idx == 1) *stop = YES;
    XCTAssertNotEqual(idx, 2U);
    ++idx;
  }];
  [dict release];
}

- (void)testEquality {
  const NSString *kKeys1[] = { @"foo", @"bar", @"baz", @"mumble" };
  const NSString *kKeys2[] = { @"bar", @"foo", @"mumble" };
  const int32_t kValues1[] = { 700, 701, 702 };
  const int32_t kValues2[] = { 700, 703, 702 };
  const int32_t kValues3[] = { 700, 701, 702, 703 };
  GPBStringEnumDictionary *dict1 =
      [[GPBStringEnumDictionary alloc] initWithValues:kValues1
                                              forKeys:kKeys1
                                                count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict1);
  GPBStringEnumDictionary *dict1prime =
      [[GPBStringEnumDictionary alloc] initWithValues:kValues1
                                              forKeys:kKeys1
                                                count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict1prime);
  GPBStringEnumDictionary *dict2 =
      [[GPBStringEnumDictionary alloc] initWithValues:kValues2
                                              forKeys:kKeys1
                                                count:GPBARRAYSIZE(kValues2)];
  XCTAssertNotNil(dict2);
  GPBStringEnumDictionary *dict3 =
      [[GPBStringEnumDictionary alloc] initWithValues:kValues1
                                              forKeys:kKeys2
                                                count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict3);
  GPBStringEnumDictionary *dict4 =
      [[GPBStringEnumDictionary alloc] initWithValues:kValues3
                                              forKeys:kKeys1
                                                count:GPBARRAYSIZE(kValues3)];
  XCTAssertNotNil(dict4);

  // 1/1Prime should be different objects, but equal.
  XCTAssertNotEqual(dict1, dict1prime);
  XCTAssertEqualObjects(dict1, dict1prime);
  // Equal, so they must have same hash.
  XCTAssertEqual([dict1 hash], [dict1prime hash]);

  // 2 is same keys, different values; not equal.
  XCTAssertNotEqualObjects(dict1, dict2);

  // 3 is different keys, same values; not equal.
  XCTAssertNotEqualObjects(dict1, dict3);

  // 4 extra pair; not equal
  XCTAssertNotEqualObjects(dict1, dict4);

  [dict1 release];
  [dict1prime release];
  [dict2 release];
  [dict3 release];
  [dict4 release];
}

- (void)testCopy {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const int32_t kValues[] = { 700, 701, 702, 703 };
  GPBStringEnumDictionary *dict =
      [[GPBStringEnumDictionary alloc] initWithValues:kValues
                                              forKeys:kKeys
                                                count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);

  GPBStringEnumDictionary *dict2 = [dict copy];
  XCTAssertNotNil(dict2);

  // Should be new object but equal.
  XCTAssertNotEqual(dict, dict2);
  XCTAssertEqualObjects(dict, dict2);
  XCTAssertTrue([dict2 isKindOfClass:[GPBStringEnumDictionary class]]);

  [dict2 release];
  [dict release];
}

- (void)testDictionaryFromDictionary {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const int32_t kValues[] = { 700, 701, 702, 703 };
  GPBStringEnumDictionary *dict =
      [[GPBStringEnumDictionary alloc] initWithValues:kValues
                                              forKeys:kKeys
                                                count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);

  GPBStringEnumDictionary *dict2 =
      [GPBStringEnumDictionary dictionaryWithDictionary:dict];
  XCTAssertNotNil(dict2);

  // Should be new pointer, but equal objects.
  XCTAssertNotEqual(dict, dict2);
  XCTAssertEqualObjects(dict, dict2);
  [dict release];
}

- (void)testAdds {
  GPBStringEnumDictionary *dict = [GPBStringEnumDictionary dictionary];
  XCTAssertNotNil(dict);

  XCTAssertEqual(dict.count, 0U);
  [dict setValue:700 forKey:@"foo"];
  XCTAssertEqual(dict.count, 1U);

  const NSString *kKeys[] = { @"bar", @"baz", @"mumble" };
  const int32_t kValues[] = { 701, 702, 703 };
  GPBStringEnumDictionary *dict2 =
      [[GPBStringEnumDictionary alloc] initWithValues:kValues
                                              forKeys:kKeys
                                                count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict2);
  [dict addRawEntriesFromDictionary:dict2];
  XCTAssertEqual(dict.count, 4U);

  int32_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 700);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 701);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 702);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 703);
  [dict2 release];
}

- (void)testRemove {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const int32_t kValues[] = { 700, 701, 702, 703 };
  GPBStringEnumDictionary *dict =
      [[GPBStringEnumDictionary alloc] initWithValues:kValues
                                       forKeys:kKeys
                                         count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 4U);

  [dict removeValueForKey:@"bar"];
  XCTAssertEqual(dict.count, 3U);
  int32_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 700);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 702);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 703);

  // Remove again does nothing.
  [dict removeValueForKey:@"bar"];
  XCTAssertEqual(dict.count, 3U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 700);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 702);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 703);

  [dict removeValueForKey:@"mumble"];
  XCTAssertEqual(dict.count, 2U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 700);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 702);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);

  [dict removeAll];
  XCTAssertEqual(dict.count, 0U);
  XCTAssertFalse([dict valueForKey:@"foo" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"baz" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);
  [dict release];
}

- (void)testInplaceMutation {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const int32_t kValues[] = { 700, 701, 702, 703 };
  GPBStringEnumDictionary *dict =
      [[GPBStringEnumDictionary alloc] initWithValues:kValues
                                       forKeys:kKeys
                                         count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 4U);
  int32_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 700);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 701);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 702);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 703);

  [dict setValue:703 forKey:@"foo"];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 703);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 701);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 702);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 703);

  [dict setValue:701 forKey:@"mumble"];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 703);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 701);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 702);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 701);

  const NSString *kKeys2[] = { @"bar", @"baz" };
  const int32_t kValues2[] = { 702, 700 };
  GPBStringEnumDictionary *dict2 =
      [[GPBStringEnumDictionary alloc] initWithValues:kValues2
                                              forKeys:kKeys2
                                                count:GPBARRAYSIZE(kValues2)];
  XCTAssertNotNil(dict2);
  [dict addRawEntriesFromDictionary:dict2];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 703);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 702);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 700);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 701);

  [dict2 release];
  [dict release];
}

@end

#pragma mark - String -> Enum (Unknown Enums)

@interface GPBStringEnumDictionaryUnknownEnumTests : XCTestCase
@end

@implementation GPBStringEnumDictionaryUnknownEnumTests

- (void)testRawBasics {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz" };
  const int32_t kValues[] = { 700, 801, 702 };
  GPBStringEnumDictionary *dict =
      [[GPBStringEnumDictionary alloc] initWithValidationFunction:TestingEnum_IsValidValue
                                                        rawValues:kValues
                                                          forKeys:kKeys
                                                            count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 3U);
  XCTAssertTrue(dict.validationFunc == TestingEnum_IsValidValue);  // Pointer comparison
  int32_t value;
  XCTAssertTrue([dict valueForKey:@"foo" rawValue:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" rawValue:&value]);
  XCTAssertEqual(value, 700);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, kGPBUnrecognizedEnumeratorValue);
  XCTAssertTrue([dict valueForKey:@"bar" rawValue:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" rawValue:&value]);
  XCTAssertEqual(value, 801);
  XCTAssertTrue([dict valueForKey:@"baz" rawValue:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" rawValue:&value]);
  XCTAssertEqual(value, 702);
  XCTAssertFalse([dict valueForKey:@"mumble" rawValue:NULL]);

  __block NSUInteger idx = 0;
  NSString **seenKeys = malloc(3 * sizeof(NSString*));
  int32_t *seenValues = malloc(3 * sizeof(int32_t));
  [dict enumerateKeysAndValuesUsingBlock:^(NSString *aKey, int32_t aValue, BOOL *stop) {
    XCTAssertLessThan(idx, 3U);
    seenKeys[idx] = aKey;
    seenValues[idx] = aValue;
    XCTAssertNotEqual(stop, NULL);
    ++idx;
  }];
  for (int i = 0; i < 3; ++i) {
    BOOL foundKey = NO;
    for (int j = 0; (j < 3) && !foundKey; ++j) {
      if ([kKeys[i] isEqual:seenKeys[j]]) {
        foundKey = YES;
        if (i == 1) {
          XCTAssertEqual(kGPBUnrecognizedEnumeratorValue, seenValues[j], @"i = %d, j = %d", i, j);
        } else {
          XCTAssertEqual(kValues[i], seenValues[j], @"i = %d, j = %d", i, j);
        }
      }
    }
    XCTAssertTrue(foundKey, @"i = %d", i);
  }
  idx = 0;
  [dict enumerateKeysAndRawValuesUsingBlock:^(NSString *aKey, int32_t aValue, BOOL *stop) {
    XCTAssertLessThan(idx, 3U);
    seenKeys[idx] = aKey;
    seenValues[idx] = aValue;
    XCTAssertNotEqual(stop, NULL);
    ++idx;
  }];
  for (int i = 0; i < 3; ++i) {
    BOOL foundKey = NO;
    for (int j = 0; (j < 3) && !foundKey; ++j) {
      if ([kKeys[i] isEqual:seenKeys[j]]) {
        foundKey = YES;
        XCTAssertEqual(kValues[i], seenValues[j], @"i = %d, j = %d", i, j);
      }
    }
    XCTAssertTrue(foundKey, @"i = %d", i);
  }
  free(seenKeys);
  free(seenValues);

  // Stopping the enumeration.
  idx = 0;
  [dict enumerateKeysAndRawValuesUsingBlock:^(NSString *aKey, int32_t aValue, BOOL *stop) {
    #pragma unused(aKey, aValue)
    if (idx == 1) *stop = YES;
    XCTAssertNotEqual(idx, 2U);
    ++idx;
  }];
  [dict release];
}

- (void)testEqualityWithUnknowns {
  const NSString *kKeys1[] = { @"foo", @"bar", @"baz", @"mumble" };
  const NSString *kKeys2[] = { @"bar", @"foo", @"mumble" };
  const int32_t kValues1[] = { 700, 801, 702 };  // Unknown
  const int32_t kValues2[] = { 700, 803, 702 };  // Unknown
  const int32_t kValues3[] = { 700, 801, 702, 803 };  // Unknowns
  GPBStringEnumDictionary *dict1 =
      [[GPBStringEnumDictionary alloc] initWithValidationFunction:TestingEnum_IsValidValue
                                                        rawValues:kValues1
                                                          forKeys:kKeys1
                                                            count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict1);
  GPBStringEnumDictionary *dict1prime =
      [[GPBStringEnumDictionary alloc] initWithValidationFunction:TestingEnum_IsValidValue
                                                        rawValues:kValues1
                                                          forKeys:kKeys1
                                                            count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict1prime);
  GPBStringEnumDictionary *dict2 =
      [[GPBStringEnumDictionary alloc] initWithValidationFunction:TestingEnum_IsValidValue
                                                        rawValues:kValues2
                                                          forKeys:kKeys1
                                                            count:GPBARRAYSIZE(kValues2)];
  XCTAssertNotNil(dict2);
  GPBStringEnumDictionary *dict3 =
      [[GPBStringEnumDictionary alloc] initWithValidationFunction:TestingEnum_IsValidValue
                                                        rawValues:kValues1
                                                          forKeys:kKeys2
                                                            count:GPBARRAYSIZE(kValues1)];
  XCTAssertNotNil(dict3);
  GPBStringEnumDictionary *dict4 =
      [[GPBStringEnumDictionary alloc] initWithValidationFunction:TestingEnum_IsValidValue
                                                        rawValues:kValues3
                                                          forKeys:kKeys1
                                                            count:GPBARRAYSIZE(kValues3)];
  XCTAssertNotNil(dict4);

  // 1/1Prime should be different objects, but equal.
  XCTAssertNotEqual(dict1, dict1prime);
  XCTAssertEqualObjects(dict1, dict1prime);
  // Equal, so they must have same hash.
  XCTAssertEqual([dict1 hash], [dict1prime hash]);

  // 2 is same keys, different values; not equal.
  XCTAssertNotEqualObjects(dict1, dict2);

  // 3 is different keys, same values; not equal.
  XCTAssertNotEqualObjects(dict1, dict3);

  // 4 extra pair; not equal
  XCTAssertNotEqualObjects(dict1, dict4);

  [dict1 release];
  [dict1prime release];
  [dict2 release];
  [dict3 release];
  [dict4 release];
}

- (void)testCopyWithUnknowns {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const int32_t kValues[] = { 700, 801, 702, 803 };  // Unknown
  GPBStringEnumDictionary *dict =
      [[GPBStringEnumDictionary alloc] initWithValidationFunction:TestingEnum_IsValidValue
                                                        rawValues:kValues
                                                          forKeys:kKeys
                                                            count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);

  GPBStringEnumDictionary *dict2 = [dict copy];
  XCTAssertNotNil(dict2);

  // Should be new pointer, but equal objects.
  XCTAssertNotEqual(dict, dict2);
  XCTAssertEqual(dict.validationFunc, dict2.validationFunc);  // Pointer comparison
  XCTAssertEqualObjects(dict, dict2);

  [dict2 release];
  [dict release];
}

- (void)testDictionaryFromDictionary {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const int32_t kValues[] = { 700, 801, 702, 803 };  // Unknowns
  GPBStringEnumDictionary *dict =
      [[GPBStringEnumDictionary alloc] initWithValidationFunction:TestingEnum_IsValidValue
                                                        rawValues:kValues
                                                          forKeys:kKeys
                                                            count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);

  GPBStringEnumDictionary *dict2 =
      [GPBStringEnumDictionary dictionaryWithDictionary:dict];
  XCTAssertNotNil(dict2);

  // Should be new pointer, but equal objects.
  XCTAssertNotEqual(dict, dict2);
  XCTAssertEqualObjects(dict, dict2);
  XCTAssertEqual(dict.validationFunc, dict2.validationFunc);  // Pointer comparison
  [dict release];
}

- (void)testUnknownAdds {
  GPBStringEnumDictionary *dict =
    [GPBStringEnumDictionary dictionaryWithValidationFunction:TestingEnum_IsValidValue];
  XCTAssertNotNil(dict);

  XCTAssertEqual(dict.count, 0U);
  XCTAssertThrowsSpecificNamed([dict setValue:801 forKey:@"bar"],  // Unknown
                               NSException, NSInvalidArgumentException);
  XCTAssertEqual(dict.count, 0U);
  [dict setRawValue:801 forKey:@"bar"];  // Unknown
  XCTAssertEqual(dict.count, 1U);

  const NSString *kKeys[] = { @"foo", @"baz", @"mumble" };
  const int32_t kValues[] = { 700, 702, 803 };  // Unknown
  GPBStringEnumDictionary *dict2 =
      [[GPBStringEnumDictionary alloc] initWithValues:kValues
                                              forKeys:kKeys
                                                count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict2);
  [dict addRawEntriesFromDictionary:dict2];
  XCTAssertEqual(dict.count, 4U);

  int32_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 700);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, kGPBUnrecognizedEnumeratorValue);
  XCTAssertTrue([dict valueForKey:@"bar" rawValue:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" rawValue:&value]);
  XCTAssertEqual(value, 801);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 702);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, kGPBUnrecognizedEnumeratorValue);
  XCTAssertTrue([dict valueForKey:@"mumble" rawValue:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" rawValue:&value]);
  XCTAssertEqual(value, 803);
  [dict2 release];
}

- (void)testUnknownRemove {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const int32_t kValues[] = { 700, 801, 702, 803 };  // Unknowns
  GPBStringEnumDictionary *dict =
      [[GPBStringEnumDictionary alloc] initWithValidationFunction:TestingEnum_IsValidValue
                                                        rawValues:kValues
                                                          forKeys:kKeys
                                                            count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 4U);

  [dict removeValueForKey:@"bar"];
  XCTAssertEqual(dict.count, 3U);
  int32_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 700);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 702);
  XCTAssertTrue([dict valueForKey:@"mumble" rawValue:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" rawValue:&value]);
  XCTAssertEqual(value, 803);

  // Remove again does nothing.
  [dict removeValueForKey:@"bar"];
  XCTAssertEqual(dict.count, 3U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 700);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 702);
  XCTAssertTrue([dict valueForKey:@"mumble" rawValue:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" rawValue:&value]);
  XCTAssertEqual(value, 803);

  [dict removeValueForKey:@"mumble"];
  XCTAssertEqual(dict.count, 2U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 700);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 702);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);

  [dict removeAll];
  XCTAssertEqual(dict.count, 0U);
  XCTAssertFalse([dict valueForKey:@"foo" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"bar" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"baz" value:NULL]);
  XCTAssertFalse([dict valueForKey:@"mumble" value:NULL]);
  [dict release];
}

- (void)testInplaceMutationUnknowns {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const int32_t kValues[] = { 700, 801, 702, 803 };  // Unknowns
  GPBStringEnumDictionary *dict =
      [[GPBStringEnumDictionary alloc] initWithValidationFunction:TestingEnum_IsValidValue
                                                        rawValues:kValues
                                                          forKeys:kKeys
                                                            count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);
  XCTAssertEqual(dict.count, 4U);
  int32_t value;
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 700);
  XCTAssertTrue([dict valueForKey:@"bar" rawValue:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" rawValue:&value]);
  XCTAssertEqual(value, 801);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 702);
  XCTAssertTrue([dict valueForKey:@"mumble" rawValue:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" rawValue:&value]);
  XCTAssertEqual(value, 803);

  XCTAssertThrowsSpecificNamed([dict setValue:803 forKey:@"foo"],  // Unknown
                               NSException, NSInvalidArgumentException);
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" value:&value]);
  XCTAssertEqual(value, 700);
  XCTAssertTrue([dict valueForKey:@"bar" rawValue:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" rawValue:&value]);
  XCTAssertEqual(value, 801);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 702);
  XCTAssertTrue([dict valueForKey:@"mumble" rawValue:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" rawValue:&value]);
  XCTAssertEqual(value, 803);

  [dict setRawValue:803 forKey:@"foo"];  // Unknown
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" rawValue:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" rawValue:&value]);
  XCTAssertEqual(value, 803);
  XCTAssertTrue([dict valueForKey:@"bar" rawValue:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" rawValue:&value]);
  XCTAssertEqual(value, 801);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 702);
  XCTAssertTrue([dict valueForKey:@"mumble" rawValue:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" rawValue:&value]);
  XCTAssertEqual(value, 803);

  [dict setRawValue:700 forKey:@"mumble"];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" rawValue:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" rawValue:&value]);
  XCTAssertEqual(value, 803);
  XCTAssertTrue([dict valueForKey:@"bar" rawValue:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" rawValue:&value]);
  XCTAssertEqual(value, 801);
  XCTAssertTrue([dict valueForKey:@"baz" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" value:&value]);
  XCTAssertEqual(value, 702);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 700);

  const NSString *kKeys2[] = { @"bar", @"baz" };
  const int32_t kValues2[] = { 702, 801 };  // Unknown
  GPBStringEnumDictionary *dict2 =
      [[GPBStringEnumDictionary alloc] initWithValidationFunction:TestingEnum_IsValidValue
                                                        rawValues:kValues2
                                                          forKeys:kKeys2
                                                            count:GPBARRAYSIZE(kValues2)];
  XCTAssertNotNil(dict2);
  [dict addRawEntriesFromDictionary:dict2];
  XCTAssertEqual(dict.count, 4U);
  XCTAssertTrue([dict valueForKey:@"foo" rawValue:NULL]);
  XCTAssertTrue([dict valueForKey:@"foo" rawValue:&value]);
  XCTAssertEqual(value, 803);
  XCTAssertTrue([dict valueForKey:@"bar" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"bar" value:&value]);
  XCTAssertEqual(value, 702);
  XCTAssertTrue([dict valueForKey:@"baz" rawValue:NULL]);
  XCTAssertTrue([dict valueForKey:@"baz" rawValue:&value]);
  XCTAssertEqual(value, 801);
  XCTAssertTrue([dict valueForKey:@"mumble" value:NULL]);
  XCTAssertTrue([dict valueForKey:@"mumble" value:&value]);
  XCTAssertEqual(value, 700);

  [dict2 release];
  [dict release];
}

- (void)testCopyUnknowns {
  const NSString *kKeys[] = { @"foo", @"bar", @"baz", @"mumble" };
  const int32_t kValues[] = { 700, 801, 702, 803 };
  GPBStringEnumDictionary *dict =
      [[GPBStringEnumDictionary alloc] initWithValidationFunction:TestingEnum_IsValidValue
                                                        rawValues:kValues
                                                          forKeys:kKeys
                                                            count:GPBARRAYSIZE(kValues)];
  XCTAssertNotNil(dict);

  GPBStringEnumDictionary *dict2 = [dict copy];
  XCTAssertNotNil(dict2);

  // Should be new pointer, but equal objects.
  XCTAssertNotEqual(dict, dict2);
  XCTAssertEqualObjects(dict, dict2);
  XCTAssertEqual(dict.validationFunc, dict2.validationFunc);  // Pointer comparison
  XCTAssertTrue([dict2 isKindOfClass:[GPBStringEnumDictionary class]]);

  [dict2 release];
  [dict release];
}

@end

//%PDDM-EXPAND-END TESTS_FOR_POD_VALUES(String, NSString, *, Objects, @"foo", @"bar", @"baz", @"mumble")

