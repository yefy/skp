package cn.epaylinks.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.SortedMap;

import org.apache.log4j.xml.DOMConfigurator;

import cn.epaylinks.service.UmpsapiService;
import cn.epaylinks.service.javabean.UmpsApiData;

public class Program {
	public static UmpsapiService service = UmpsapiService.getInstance();
	static{
		DOMConfigurator.configure("resource/log4jConfig.xml");	
	}
	//使用main方法进行测试
	public static void main(String[] args) {
		Program p = new Program();
		//账户注册
		//p.register();
		p.userLogin();
	}
	
	/**
	 * 接口调用说明(以register为例)
	 * 接口文档参照：UMPS账户支付API（云账户）.docx
	 * 步骤：
	 * 1、实例化UmpsApiData
	 * 2、设置参数 key-value形式，key必须与文档中字段一致
	 *    注：系统级必填参数在resource/umpsapi_config.properties中配置即可，无需设置
	 *        系统级选填参数可设置可不设置
	 *        应用级必填参数必须设置，可选参数根据需要设置
	 *    另：对于加密字段设置时不进行加密，sdk中后面会自行加密处理
	 *        对于需要转码的字段，请在此进行转码
	 * 3、使用UmpsapiService调用对应的sdk接口 （接口的方法名称与接口文档中api_name对应）
	 * 4、获取到返回结果
	 * 	   注：若交互过程中发生异常，请捕获异常，并根据实际情况另行发起交易查询请求
	 */
	public void register(){
		UmpsApiData data = new UmpsApiData();
		data.setRequestParam("busi_water_no", System.currentTimeMillis()+"");
		data.setRequestParam("cust_name", "张三");
		data.setRequestParam("login_passwd", "123456");
		data.setRequestParam("pay_passwd", "123456");
		try {
			SortedMap<String,String> map = service.umpsRegisterAccount(data);
			this.printSortedMap(map);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void userLogin(){
		UmpsApiData data = new UmpsApiData();
		data.setRequestParam("acct_id", "5387380003338181");
		data.setRequestParam("busi_water_no", System.currentTimeMillis()+"");
		data.setRequestParam("login_passwd", "123456");
		data.setRequestParam("device_info", "电脑");
		try {
			SortedMap<String,String> map = service.umpsUserLogin(data);
			this.printSortedMap(map);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void batchTransfer(){
		UmpsApiData data = new UmpsApiData();
		data.setRequestParam("card_no", "13456565");
		data.setRequestParam("mer_batch_no", System.currentTimeMillis()+"");
		data.setRequestParam("total_amount", "6400");
		data.setRequestParam("total_count", "2");
		
		List<HashMap<String,Object>> details = new ArrayList<HashMap<String,Object>>();
		HashMap<String,Object> detail1 = new HashMap<String,Object>();
		detail1.put("sn", "1");
		detail1.put("order_amount", "3200");
		detail1.put("rec_card_no", "45643516874121564");
		details.add(detail1);
		HashMap<String,Object> detail2 = new HashMap<String,Object>();
		detail2.put("sn", "2");
		detail2.put("order_amount", "3200");
		detail2.put("rec_card_no", "45643516874121564");
		details.add(detail2);
		try {
			SortedMap<String,String> map = service.umpsAccountTransferBatch(data, details);
			this.printSortedMap(map);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	public void queryTransStatus(){
		UmpsApiData data = new UmpsApiData();
		data.setRequestParam("mer_batch_no", "5134564156");
		try {
			SortedMap<String,String> map = service.umpsTransStatusQuery(data);
			this.printSortedMap(map);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	
	
	
	

	private void printSortedMap(SortedMap<String, String> map) {
		// TODO Auto-generated method stub
		System.out.println("========打印Map========");
		for (String key : map.keySet()) {
            if (map.get(key) != null && !"".equals(map.get(key))
            		&&!"sign".equals(key)) {
            	System.out.println(key+"--->"+map.get(key));
            }
        }
	}
}
