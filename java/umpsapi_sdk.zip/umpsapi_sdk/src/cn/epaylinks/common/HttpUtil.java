package cn.epaylinks.common;

/**
 * Created with IntelliJ IDEA.
 * User: xiash
 * Date: 14-4-10
 * Time: 下午2:47
 * To change this template use File | Settings | File Templates.
 */
public class HttpUtil {
    
    public static String sendPost(String url,String param,String encoding){
    	HttpClient hc = new HttpClient(url, 30000, 30000);
    	String resultString = "";
    	try {
			int status = hc.send(param, encoding);
			if (200 == status) {
				resultString = hc.getResult();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return resultString;
    }
}