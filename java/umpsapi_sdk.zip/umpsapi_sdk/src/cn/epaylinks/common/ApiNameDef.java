package cn.epaylinks.common;

/**
 * Created by IntelliJ IDEA.
 * User: Yan.L
 * Date: 2015/5/3
 * Time: 11:04
 * To change this template use File | Settings | File Templates.
 */

public enum ApiNameDef {

    epaylinks_user_open_account("epaylinks_user_open_account"),
    epaylinks_user_real_name("epaylinks_user_real_name"),
    epaylinks_user_physical_card_apply("epaylinks_user_physical_card_apply"),
    epaylinks_user_physical_card_activate("epaylinks_user_physical_card_activate"),
    epaylinks_user_status_query("epaylinks_user_status_query"),
    epaylinks_user_card_loss("epaylinks_user_card_loss"),
    epaylinks_user_change_passwd("epaylinks_user_change_passwd"),
    epaylinks_user_reset_passwd("epaylinks_user_reset_passwd"),
    epaylinks_user_sign_account("epaylinks_user_sign_account"),
    epaylinks_user_query_acct_info("epaylinks_user_query_acct_info"),
    epaylinks_user_query_tran_detail("epaylinks_user_query_tran_detail"),

    epaylinks_umps_user_open_account("epaylinks_umps_user_open_account"),
    epaylinks_umps_user_login("epaylinks_umps_user_login"),
    epaylinks_umps_user_logout("epaylinks_umps_user_logout"),
    epaylinks_umps_user_real_name("epaylinks_umps_user_real_name"),
    epaylinks_umps_user_physical_card_apply("epaylinks_umps_user_physical_card_apply"),
    epaylinks_umps_user_physical_card_activate("epaylinks_umps_user_physical_card_activate"),
    epaylinks_umps_user_status_query("epaylinks_umps_user_status_query"),
    epaylinks_umps_user_card_loss("epaylinks_umps_user_card_loss"),
    epaylinks_umps_user_change_passwd("epaylinks_umps_user_change_passwd"),
    epaylinks_umps_user_reset_passwd("epaylinks_umps_user_reset_passwd"),
    epaylinks_umps_user_sign_account("epaylinks_umps_user_sign_account"),
    epaylinks_umps_user_sign_bank_acc("epaylinks_umps_user_sign_bank_acc"),
    epaylinks_umps_user_query_acct_info("epaylinks_umps_user_query_acct_info"),
    epaylinks_umps_user_query_tran_detail("epaylinks_umps_user_query_tran_detail"),
    epaylinks_umps_user_verify_sms("epaylinks_umps_user_verify_sms"),
    epaylinks_umps_user_refresh_token("epaylinks_umps_user_refresh_token"),

    epaylinks_umps_user_verify_code("epaylinks_umps_user_verify_code"),
    epaylinks_umps_user_reset_passwd_self("epaylinks_umps_user_reset_passwd_self"),
    epaylinks_umps_user_query_certain_user_info("epaylinks_umps_user_query_certain_user_info"),
    epaylinks_umps_user_card_query("epaylinks_umps_user_card_query"),
    epaylinks_umps_user_account_bind("epaylinks_umps_user_account_bind"),
    epaylinks_umps_user_mod_cust_passwd("epaylinks_umps_user_mod_cust_passwd"),

    epaylinks_wallet_cust_reg("epaylinks_wallet_cust_reg"),
    epaylinks_wallet_cust_login("epaylinks_wallet_cust_login"),
    epaylinks_wallet_cust_card_qry("epaylinks_wallet_cust_card_qry"),
    epaylinks_wallet_oper_cust_card("epaylinks_wallet_oper_cust_card"),
    epaylinks_wallet_check_mob("epaylinks_wallet_check_mob"),
    epaylinks_wallet_change_account("epaylinks_wallet_change_account"),
    epaylinks_wallet_account_bind("epaylinks_wallet_account_bind"),
    epaylinks_wallet_mod_realname_info("epaylinks_wallet_mod_realname_info"),
    
    epaylinks_gateway_pay("epaylinks_gateway_pay"),
    epaylinks_gateway_status_query("epaylinks_gateway_status_query"),
    epaylinks_gateway_refund("epaylinks_gateway_refund"),
    epaylinks_gateway_refund_query("epaylinks_gateway_refund_query"),
    epaylinks_trans_account_recharge("epaylinks_trans_account_recharge"),
    epaylinks_trans_account_consume("epaylinks_trans_account_consume"),
    epaylinks_trans_account_pay_report("epaylinks_trans_account_pay_report"),
    epaylinks_trans_account_transfer("epaylinks_trans_account_transfer"),
    epaylinks_trans_account_transfer_batch("epaylinks_trans_account_transfer_batch"),
    epaylinks_trans_account_withdraw("epaylinks_trans_account_withdraw"),
    epaylinks_trans_account_transfer_tobank_batch("epaylinks_trans_account_transfer_tobank_batch"),
    epaylinks_trans_status_query("epaylinks_trans_status_query"),

    epaylinks_umps_member_apply_stores_qry("epaylinks_umps_member_apply_stores_qry"),
    epaylinks_umps_member_card_list_qry("epaylinks_umps_member_card_list_qry"),
    epaylinks_umps_merchant_list_qry("epaylinks_umps_merchant_list_qry"),
    epaylinks_umps_virtual_member_card_apply("epaylinks_umps_virtual_member_card_apply"),
    epaylinks_umps_virtual_member_card_qry("epaylinks_umps_virtual_member_card_qry"),
    epaylinks_umps_query_trans_detail("epaylinks_umps_query_trans_detail"),
    epaylinks_umps_get_pay_token("epaylinks_umps_get_pay_token"),


    epaylinks_util_file_upload("epaylinks_util_file_upload"),

    epaylinks_public_query_bank("epaylinks_public_query_bank"),
    epaylinks_public_query_area("epaylinks_public_query_area"),
    epaylinks_public_query_branch("epaylinks_public_query_branch"),

    epaylinks_fund_open_stateaccount("epaylinks_fund_open_stateaccount"),
    epaylinks_fund_open_personalaccount("epaylinks_fund_open_personalaccount"),
    epaylinks_fund_transfer_in("epaylinks_fund_transfer_in"),
    epaylinks_fund_transfer_out("epaylinks_fund_transfer_out"),
    epaylinks_fund_query_accountinfo("epaylinks_fund_query_accountinfo"),
    epaylinks_fund_query_fund_list("epaylinks_fund_query_fund_list"),
    epaylinks_fund_query_trade_detail_list("epaylinks_fund_query_trade_detail_list"),
    epaylinks_fund_query_personal_state("epaylinks_fund_query_personal_state");
    
    ApiNameDef(String apiName) {
        this.apiName = apiName;
    }

    private String apiName;


    @Override
    public String toString() {
        return this.apiName;
    }
}
