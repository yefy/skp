/*
 * Copyright (c) 2007 Your Corporation. All Rights Reserved.
 */
package cn.epaylinks.common.sign;

/**
 * Created by IntelliJ IDEA.
 * User: Administrator
 * Date: 2007-6-20
 * Time: 17:12:07
 * To change this template use File | Settings | File Templates.
 */
public interface Translator {
      /**
     * size of the output block on encoding produced by getDecodedBlockSize()
     * bytes.
     */
    public int getEncodedBlockSize();

    public int encode(byte[] in, int inOff, int length, byte[] out, int outOff);

    /**
     * size of the output block on decoding produced by getEncodedBlockSize()
     * bytes.
     */
    public int getDecodedBlockSize();

    public int decode(byte[] in, int inOff, int length, byte[] out, int outOff);
}

