package cn.epaylinks.common.sign;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import org.apache.commons.codec.binary.Base64;


import cn.epaylinks.common.security.RsaHelper;

public class SignTool {
	private static RsaHelper rsaHelper = null;
	
	/**
	 * 敏感数据加密 1、MD5  2、公钥RSA 3、base64
	 * @param sensitiveInfo
	 * @return
	 */
	public static String makeEncrypt(String sensitiveInfo){
        String encryp = "";
        try{
            String md5Str = SafeHelper.digestHex(sensitiveInfo);
            
            if(rsaHelper==null){
                rsaHelper = ApiSecurityUtil.getRsaHelper(1);
            }
            byte[] rsaBytes = rsaHelper.encryptByPublicKey(md5Str.getBytes());
            encryp = new String(Base64.encodeBase64(rsaBytes));
        }catch (Exception e){
            e.printStackTrace();
        }
        return encryp;
    }
	
	public static void main(String[] args) {
		try {
			
			String rsaStr = SignTool.makeEncrypt("123456");
			String md5Str = SafeHelper.digestHex("123456");
			System.out.println(md5Str);
			System.out.println(rsaStr);
			FileInputStream file = new FileInputStream("D:/apikey/umpsapi-staging.pfx");
			RsaHelper helper = new RsaHelper();
			//helper.loadPrivateKeyPEMPKCS1(file);
			helper.loadPrivateKeyPFX(file, "123456");
			byte[] bytes = helper.decryptByPrivateKey(Base64.decodeBase64("mBQ02mnp5WIyU6cKera+p0XE1/CHeoqAglbyB3SgC2OPkclZgjeh/cqEn4P7xKKZu+S9nHkfDEXwYPZc7DGfyp6dbeef38CUZO2klLA2f9x2u2ckUGfi1dgTGEwtu3/GZBdiNGSDitPsUHEg2I4HZfByT2DHmsAuG/0QcHSumZ5Obof+YXAR7kM68I3Evy4WfUVZ4B/lA79n8/zDr68okMn1qWcnYiwHa2KWcUy2OHRSN0RaBUMGd+UAD29on8cj7K+vkYWGRFVbtH8jcNz1paoBvW9K4/cfGAoIiy5KmqnRbfFw1zrOLSmJ39O424JXLP0Ln4IISmKM6TYeORRX+w=="));
			
			String str = new String(bytes);
			System.out.println(str);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
