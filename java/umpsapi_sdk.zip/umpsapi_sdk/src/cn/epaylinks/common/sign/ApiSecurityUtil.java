package cn.epaylinks.common.sign;

import cn.epaylinks.common.Parameters;
import cn.epaylinks.common.security.RsaHelper;


import java.io.*;

/**
 * Created by IntelliJ IDEA.
 * User: Yan.L
 * Date: 2015/5/4
 * Time: 11:36
 * To change this template use File | Settings | File Templates.
 */

public class ApiSecurityUtil {

    public static int EPAY_PUBLIC_KEY = 1;
    public static int MY_PRIVATE_KEY = 2;
    
    public static String EPAY_PUBLIC_KEY_PATH = Parameters.getProperty("EPAY_PUBLIC_KEY_PATH");
    public static String MY_PRIVATE_KEY_PATH = Parameters.getProperty("MY_PRIVATE_KEY_PATH");

    public static RsaHelper getRsaHelper(int keyType) throws Exception {
        RsaHelper helper = new RsaHelper();
        
        if (keyType == EPAY_PUBLIC_KEY) {
            FileInputStream file = new FileInputStream(EPAY_PUBLIC_KEY_PATH);
            //helper.loadPublicKeyCRT(file);
            helper.loadPublicKeyPEM(file);
            file.close();
            return helper;
        }else if (keyType == MY_PRIVATE_KEY) {
            FileInputStream file = new FileInputStream(MY_PRIVATE_KEY_PATH);
            helper.loadPrivateKeyPFX(file,Parameters.getProperty("PRIVATE_KEY"));
            file.close();
            return helper;
        } else
            return null;
    }

    public static byte[] readFileToByte(){
        byte[] buffer = null;
        try {
            FileInputStream file = new FileInputStream(EPAY_PUBLIC_KEY_PATH);
            ByteArrayOutputStream bos = new ByteArrayOutputStream(1000);
            byte[] b = new byte[1000];
            int n;
            while ((n = file.read(b)) != -1) {
                bos.write(b, 0, n);
            }
            file.close();
            bos.close();
            buffer = bos.toByteArray();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return buffer;
    }



}
