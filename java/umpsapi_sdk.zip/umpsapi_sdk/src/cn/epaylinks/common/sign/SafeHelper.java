package cn.epaylinks.common.sign;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import java.security.MessageDigest;

public class SafeHelper {
	/**
     * 进行DES加密
     * param clearText String 明文
     * param secretKey String 密钥
     * return String 密文
     */
    public static String encrypt(String srcMsg, String sKey) throws Exception{
        String encMsg;
        SecretKey secretKey;
        BASE64Encoder encoder = new BASE64Encoder();

        try {
            SecretKeyFactory keyFac = SecretKeyFactory.getInstance("DES");
            DESKeySpec desKeySpec;

            desKeySpec   = new DESKeySpec(sKey.getBytes());
            secretKey = keyFac.generateSecret(desKeySpec);

            Cipher desCipher = Cipher.getInstance("DES");
            desCipher.init(Cipher.ENCRYPT_MODE, secretKey);

            byte[] encText = desCipher.doFinal(srcMsg.getBytes());
            encMsg = encoder.encode(encText);
        } catch(Exception ex) {
            System.out.println(ex);
            throw new Exception("无法进行加密！");
        }
        return encMsg;

    }
    
    
    public static byte[] encryptDES(byte[] data, byte[] key) {
		byte[] encryptedData = null;
		try {
			DESKeySpec dks = new DESKeySpec(key);
			// 创建一个密匙工厂，然后用它把DESKeySpec转换成一个SecretKey对象
			SecretKeyFactory keyFactory = SecretKeyFactory.getInstance("DES");
			SecretKey sk = keyFactory.generateSecret(dks);

			// Cipher对象实际完成加密操作
			Cipher cipher = Cipher.getInstance("DES/ECB/NoPadding");

			// 用密匙初始化Cipher对象
			cipher.init(Cipher.ENCRYPT_MODE, sk);

			// 执行加密操作
			encryptedData = cipher.doFinal(data);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return encryptedData;

	}
    
    /**
     * 进行DES解密
     * param cipherText String 密文
     * param secretKey String 密钥
     * return String 原文
     */
    public static String decrypt(String encMsg, String sKey) throws Exception {
        String srcMsg;
        SecretKey secretKey;
        BASE64Decoder decoder = new BASE64Decoder();

        if(encMsg==null || encMsg.length()<=0) throw new Exception("指定的密文格式不正确！");
        try {
            SecretKeyFactory keyFac = SecretKeyFactory.getInstance("DES");
            DESKeySpec desKeySpec;

            desKeySpec   = new DESKeySpec(sKey.getBytes());
            secretKey = keyFac.generateSecret(desKeySpec);

            Cipher desCipher = Cipher.getInstance("DES");
            desCipher.init(Cipher.DECRYPT_MODE, secretKey);

            byte[] srcText = desCipher.doFinal(decoder.decodeBuffer(encMsg));
            srcMsg = new String(srcText);

        } catch(Exception ex) {
            System.out.println("ex = " + ex);
            throw new Exception("无法对信息进行解密！");
        }
        return srcMsg;
    }
    /**
     * 对指定的文本进行MD5摘要
     * param text String 文本
     * return String 摘要
     */
    public static String digest(String clearText) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] digestText = md.digest(clearText.getBytes());

        BASE64Encoder encoder = new BASE64Encoder();
        return encoder.encode(digestText).toString();
    }
    public static String digestHex(String clearText) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] digestText = md.digest(clearText.getBytes());
        byte[] bytes = Hex.encode(digestText);
        return new String(bytes);
    }
    public static String digestHexUTF8(String clearText) throws Exception {
        MessageDigest md = MessageDigest.getInstance("MD5");
        byte[] digestText = md.digest(clearText.getBytes("UTF-8"));
        byte[] bytes = Hex.encode(digestText);
        return new String(bytes);
    }
    /**
     * 对指定的文本进行BASE64编码
     * @param text String 文本
     * @return String 文本的BASE64编码
     */
    public static String encode(String text) {
        BASE64Encoder encoder =new BASE64Encoder();
        return encoder.encode(text.getBytes()).toString();
    }

    /**
     * 取得BASE64编码的原文
     * @param text String BASE64编码文本
     * @return String 原文
     */
    public static String decode(String text) throws Exception {
        BASE64Decoder decoder =new BASE64Decoder();
        return new String(decoder.decodeBuffer(text)).toString();
    }
   public static void main(String[] args){
       try {
          //String str=SafeHelper.encode("088969919318339224");
          // System.out.println("str = " + str);
           /*System.out.println("str = " + SafeHelper.decode("MzY4OTcxNTQyNzkyMzE2ODYy"));
           System.out.println("str = " + SafeHelper.decode("MDk3MTk1MjAyODc5MzQ1ODU1"));
           System.out.println("str = " + SafeHelper.decode("MjE0MjIxMDkyODExNTAzNDI0"));
           System.out.println("str = " + SafeHelper.decode("MzI4ODMzMTQ1NzAxODM4MTU1"));
           System.out.println("str = " + SafeHelper.decode("MzkwOTE5OTUyMTUwNjc1MDgz"));*/
           StringBuffer sb=new StringBuffer();
           String str="";
           String[] s=str.split("\n");
           for (int i = 0; i < s.length; i++) {
               String s1 = s[i];
              // System.out.println("s1 = " + s1);
               String[] s2=s1.split("\\|");
               sb.append(s2[0]+"|").append(s2[1]+"|").append(SafeHelper.decode(s2[2])+"|").append(s2[3]+"|"+"\n");
           }
           System.out.println("sb = " + sb.toString());
       } catch (Exception e) {
           e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
       }
   }
}
