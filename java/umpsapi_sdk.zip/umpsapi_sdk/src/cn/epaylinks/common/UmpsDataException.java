package cn.epaylinks.common;

public class UmpsDataException extends RuntimeException {
	private static final long serialVersionUID = -6956666213410640672L;
	private String errorCode;
	public UmpsDataException()
	{
	}
	
	public UmpsDataException(String message)
	{
		super(message);
	}
	
	public UmpsDataException(String message,String errorCode)
	{
		super(message);
		this.errorCode = errorCode;
	}
	
	public UmpsDataException(String message,Throwable root)
	{
		super(message);
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	
}
