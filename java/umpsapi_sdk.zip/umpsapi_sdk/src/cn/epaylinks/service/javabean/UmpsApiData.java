package cn.epaylinks.service.javabean;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.util.Date;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;
import java.util.Map.Entry;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONObject;

import cn.epaylinks.common.HttpUtil;
import cn.epaylinks.common.Parameters;
import cn.epaylinks.common.Tool;
import cn.epaylinks.common.UmpsDataException;
import cn.epaylinks.common.security.RsaHelper;
import cn.epaylinks.common.sign.ApiSecurityUtil;
import cn.epaylinks.common.util.SignUtil;

public class UmpsApiData {
	private static final Logger logger = Logger.getLogger(UmpsApiData.class);
	private static String url = Parameters.getProperty("URL");
	/**
	 * 请求参数
	 */
	private SortedMap<String,String> requestParams;
	/**
	 * 响应参数
	 */
	private SortedMap<String,String> responseParams;
	
	public UmpsApiData(){
		this.requestParams = new TreeMap<String, String>();
		this.responseParams = new TreeMap<String, String>();
		this.setRequestParam("ver", Parameters.getProperty("ver"));
		this.setRequestParam("format", Parameters.getProperty("format"));
		this.setRequestParam("app_id", Parameters.getProperty("app_id"));
		this.setRequestParam("terminal_no", Parameters.getProperty("terminal_no"));
		this.setRequestParam("timestamp", Tool.dateToString(new Date(), "yyyy-MM-dd HH:mm:ss"));
	}
	
	public String makeSign(){
		String sign = null;
		FileInputStream file = null;
        try {
            StringBuffer sb = new StringBuffer("");
            for (String key : this.getRequestParams().keySet()) {
                if (this.getRequestParam(key) != null && !"".equals(this.getRequestParam(key))
                		&&!"sign".equals(key)) {
                    sb.append(key).append("=").append(this.getRequestParam(key)).append("&");
                }
            }
            String str = sb.toString().substring(0, sb.toString().length() - 1);

            //加签方式
            String encrypt_type=Parameters.getProperty("ENCRYPT_TYPE"); //SHA1WithRSA 或 MD5WithRSA
            file= new FileInputStream(Parameters.getProperty("MY_PRIVATE_KEY_PATH"));
            RsaHelper helper = new RsaHelper();
            if("pfx".equals(Parameters.getProperty("KEY_TYPE").toLowerCase())){
            	helper.loadPrivateKeyPFX(file, Parameters.getProperty("PRIVATE_KEY"));
            }else if("pem".equals(Parameters.getProperty("KEY_TYPE").toLowerCase())){
            	helper.loadPrivateKeyPEMPKCS1(file);
            }else{
            	throw new UmpsDataException("无法识别证书类型");
            }
            
            sign = SignUtil.sign(str,helper,encrypt_type);
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
        	try {
				file.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
        }
        return sign;
	}
	
	public String toRequestParmaUrl() throws Exception{
		StringBuffer sb = new StringBuffer("");
        String val = "";
        for (String key : this.getRequestParams().keySet()) {
            val = this.getRequestParam(key).toString();
            if (Tool.isNotNullOrEmpty(val)) {
                val = URLEncoder.encode(val, "UTF-8");
                sb.append(key).append("=").append(val).append("&");
            }
        }
        return sb.toString().substring(0, sb.toString().length() - 1);
	}
	
	/**
	 * 后台直连请求，同步报文返回
	 * @throws Exception
	 */
	public void sendAndGetUmpsResponse() throws Exception {
		//生成签名
		String sign = this.makeSign();
		//设置签名到请求参数中
		this.setRequestParam("sign", sign);
		//得到请求参数字符串
		String requestStr = this.toRequestParmaUrl();
		String httpUrl = url + "?" + requestStr;
		logger.info("请求url:"+httpUrl);
        String responseStr = HttpUtil.sendPost(url, requestStr,"UTF-8");
        logger.info("响应报文："+responseStr);
        //解析报文并设置到responseParam
        this.fromJson(responseStr);
        if("0000".equals(this.getResponseParam("resp_code"))){
	        if(!this.verifySign(this.getResponseParams())){
	        	logger.info("签名验证失败");
	        	throw new UmpsDataException("签名验证失败");
	        }
        }
	}
	
	/**
	 * 前台网页跳转交易
	 * @param response
	 */
	public void sendHtmlPost(String url,HttpServletResponse response,String encoding) {
		// TODO Auto-generated method stub
		
		StringBuffer sf = new StringBuffer();
		sf.append("<html><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset="+encoding+"\"/></head><body>");
		sf.append("<form id = \"pay_form\" action=\"" + url
				+ "\" method=\"post\">");
		if (null != this.getRequestParams() && 0 != this.getRequestParams().size()) {
			Set<Entry<String, String>> set = this.getRequestParams().entrySet();
			Iterator<Entry<String, String>> it = set.iterator();
			while (it.hasNext()) {
				Entry<String, String> ey = it.next();
				String key = ey.getKey();
				String value = ey.getValue();
				sf.append("<input type=\"hidden\" name=\"" + key + "\" id=\""
						+ key + "\" value=\"" + value + "\"/>");
			}
		}
		sf.append("</form>");
		sf.append("</body>");
		sf.append("<script type=\"text/javascript\">");
		sf.append("document.all.pay_form.submit();");
		sf.append("</script>");
		sf.append("</html>");
		PrintWriter writer;
		try {
			writer = response.getWriter();
			writer.write(sf.toString());
			writer.flush();
			writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
	/**
	 * 将响应报文解析到Map
	 * @param responseJson
	 */
	public void fromJson(String responseJson) throws Exception{
		JSONObject json = JSONObject.parseObject(responseJson);
		Set<String> set = json.keySet();
		for (String key : set) {
			if(json.get(key)!=null){
                Object valueObj = json.get(key);
                if(valueObj instanceof JSONObject){
                    String value = responseJson.substring(responseJson.indexOf(key)+key.length()+2);
                    int j = 0;
                    for(int i = value.indexOf("{") ;i<value.length();i++){
                        if(value.charAt(i)=='{'){
                            j++;
                        }
                        if(value.charAt(i)=='}'){
                            j--;
                        }
                        if(j==0){
                            value = value.substring(value.indexOf("{"),i+1);
                            break;
                        }
                    }
                    this.setResponseParam(key, value);
                }else {
                    String value = valueObj.toString();
                    this.setResponseParam(key, value);
                }
            }
		}
		if("0000".equals(this.getResponseParam("resp_code"))){
	        if(!this.verifySign(this.getResponseParams())){
	        	throw new UmpsDataException("签名验证失败");
	        }
	    }
	}
	
	/**
	 * 将响应报文解析到Map并验证签名
	 * @param request
	 */
	public void fromRequest(HttpServletRequest request)throws Exception{
		Enumeration<?> temp = request.getParameterNames();
		if (null != temp) {
			while (temp.hasMoreElements()) {
				String en = (String) temp.nextElement();
				String value = request.getParameter(en);
				this.setResponseParam(en, value);
				// 在报文上送时，如果字段的值为空，则不上送<下面的处理为在获取所有参数数据时，判断若值为空，则删除这个字段>
				if (this.getResponseParam(en) == null || "".equals(this.getResponseParam(en))) {
					// System.out.println("======为空的字段名===="+en);
					this.responseParams.remove(en);
				}
			}
		}
		if("0000".equals(this.getResponseParam("resp_code"))){
	        if(!this.verifySign(this.getResponseParams())){
	        	throw new UmpsDataException("签名验证失败");
	        }
	    }
	}
	
	public boolean verifySign(SortedMap<String,String> map) throws Exception {
		// TODO Auto-generated method stub
		//1、json转map
		boolean flag = false;
        try {
            String recSign = (String)map.get("sign");
            RsaHelper rsaHelper = ApiSecurityUtil.getRsaHelper(1);
            flag = SignUtil.checkSign(recSign, (Map<String,String>)map, "sign", rsaHelper,"MD5withRSA");
        } catch (Exception e) {
            flag = false;
            e.printStackTrace();
        }
        return flag;
	}
	
	

	public SortedMap<String, String> getRequestParams() {
		return requestParams;
	}

	public void setRequestParams(SortedMap<String, String> requestParams) {
		this.requestParams = requestParams;
	}

	public SortedMap<String, String> getResponseParams() {
		return responseParams;
	}

	public void setResponseParams(SortedMap<String, String> responseParams) {
		this.responseParams = responseParams;
	}
	
	public void setRequestParam(String key,String value){
		this.requestParams.put(key, value);
	}
	
	public String getRequestParam(String key){
		String ret = "";
		if(this.requestParams.containsKey(key)){
			ret = this.requestParams.get(key);
		}
		return ret;
	}
	
	public void setResponseParam(String key,String value){
		this.responseParams.put(key, value);
	}
	
	public String getResponseParam(String key){
		String ret = "";
		if(this.responseParams.containsKey(key)){
			ret = this.responseParams.get(key);
		}
		return ret;
	}
}
