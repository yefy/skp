package cn.epaylinks.service;

import java.util.HashMap;
import java.util.List;
import java.util.SortedMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.alibaba.fastjson.JSONObject;

import cn.epaylinks.common.ApiNameDef;
import cn.epaylinks.common.Tool;
import cn.epaylinks.common.sign.SignTool;
import cn.epaylinks.service.javabean.UmpsApiData;

/**
 * 易票联umps接口sdk总入口
 * 该类定义了各种交易接口对应的接入方法（方法已集成了加密、签名、验签等操作）
 * 接入者只需传入对应接口必须的参数即可实现与易票联umps的各种交易
 * 入参说明：必传应用级必填参数，系统级可选参数和应用级可选参数可传可不传，参数无需加密
 * @author Administrator
 *
 */
public class UmpsapiService {
	private static final Logger logger = Logger.getLogger(UmpsapiService.class);
	private static UmpsapiService umpsapiService = new UmpsapiService();
	
	
	private UmpsapiService(){}
	
	public static UmpsapiService getInstance(){
		return umpsapiService;
	}
	
	
	/**
	 * 交易通用umps接口方法
	 * @param data  入参说明：必传应用级必填参数，系统级可选参数和应用级可选参数可传可不传，参数无需加密
	 * @param apiName
	 * @return 同步结果返回
	 * @throws Exception
	 */
	public SortedMap<String,String> sendUmps(UmpsApiData data, String apiName) throws Exception {
		//设置默认参数
		data.setRequestParam("api_name",apiName);
		umpsMakeEncrypt(data);
		//签名、发起请求，将响应报文封装到responseParams中
		data.sendAndGetUmpsResponse();
		return data.getResponseParams();
	}
	
	/**
	 * 前台交易通用umps接口方法，无返回（请接收同步或异步通知）
	 * @param url 前台请求地址，调用本方法直接跳转页面
	 * @param data
	 * @param response
	 * @param encoding
	 * @param apiName
	 */
	public void sendHtmlUmps(String url, UmpsApiData data,
			HttpServletResponse response, String encoding, String apiName) {
		data.setRequestParam("api_name",apiName);
		//对敏感数据加密
		umpsMakeEncrypt(data);
		data.sendHtmlPost(url,response,encoding);
	}
	
	/**
	 * 获取异步通知过来的参数并验证签名
	 * 注意：如果是同步通知，在处理完本地业务后，请返回应答消息success/fail 本方法中不做应答
	 * @param request
	 * @return
	 */
	public SortedMap<String,String> getNotifyResponseParam(HttpServletRequest request) throws Exception{
		UmpsApiData data = new UmpsApiData();
		data.fromRequest(request);
		return data.getResponseParams();
	}

	/**
	 * 敏感信息加密
	 * @param data
	 */
	private void umpsMakeEncrypt(UmpsApiData data) {
		if(Tool.isNotNullOrEmpty((String)data.getRequestParam("login_passwd"))){
			data.setRequestParam("login_passwd", SignTool.makeEncrypt((String)data.getRequestParam("login_passwd")));
		}
		if(Tool.isNotNullOrEmpty((String)data.getRequestParam("pay_passwd"))){
			data.setRequestParam("pay_passwd", SignTool.makeEncrypt((String)data.getRequestParam("pay_passwd")));
		}
		if(Tool.isNotNullOrEmpty((String)data.getRequestParam("card_verify_code"))){
			data.setRequestParam("card_verify_code", SignTool.makeEncrypt((String)data.getRequestParam("card_verify_code")));
		}
		if(Tool.isNotNullOrEmpty((String)data.getRequestParam("new_passwd"))){
			data.setRequestParam("new_passwd", SignTool.makeEncrypt((String)data.getRequestParam("new_passwd")));
		}
	}
	
	/**
	 * 注册账户
	 * 用于向易票联申请账户通支付账号
	 * @param data
	 * @return
	 * @throws Exception 
	 */
	public SortedMap<String,String> umpsRegisterAccount(UmpsApiData data) throws Exception {
		logger.info("===============注册账户请求开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_open_account.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============注册账户结束===============");
		return result;
	}

	
	/**
	 * 用户登录，在访问需要鉴权的接口时，需要先登录
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserLogin(UmpsApiData data) throws Exception {
		logger.info("===============用户登录请求开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_login.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============用户登录结束===============");
		return result;
	}

	/**
	 * 用户登出
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserLogout(UmpsApiData data) throws Exception {
		logger.info("===============用户登出请求开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_logout.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============用户登出结束===============");
		return result;
	}
	
	/**
	 * 用户实名认证
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserRealName(UmpsApiData data) throws Exception {
		logger.info("===============用户实名认证开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_real_name.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============用户实名认证结束===============");
		return result;
	}

	/**
	 * 实体卡申请
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserPhysicalCardApply(UmpsApiData data) throws Exception {
		logger.info("===============实体卡申请开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_physical_card_apply.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============实体卡申请结束===============");
		return result;
	}
	
	/**
	 * 实体卡激活
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserPhysicalCardActivate(UmpsApiData data) throws Exception {
		logger.info("===============实体卡激活开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_physical_card_activate.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============实体卡激活结束===============");
		return result;
	}
	
	/**
	 * 账务业务状态查询
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserStatusQuery(UmpsApiData data) throws Exception {
		logger.info("===============账务业务状态查询开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_status_query.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============账务业务状态查询结束===============");
		return result;
	}
	
	/**
	 * 卡挂失
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserCardLoss(UmpsApiData data) throws Exception {
		logger.info("===============卡挂失开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_card_loss.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============卡挂失结束===============");
		return result;
	}
	
	/**
	 * 修改密码
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserChangePasswd(UmpsApiData data) throws Exception {
		logger.info("===============修改密码开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_change_passwd.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============修改密码结束===============");
		return result;
	}
	
	/**
	 * 重设密码
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserResetPasswd(UmpsApiData data) throws Exception {
		logger.info("===============重设密码开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_reset_passwd.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============重设密码结束===============");
		return result;
	}
	
	/**
	 * 账户签约
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserSignAccount(UmpsApiData data) throws Exception {
		logger.info("===============账户签约开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_sign_account.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============账户签约结束===============");
		return result;
	}
	
	/**
	 * 关联银行卡
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserSignBankAcc(UmpsApiData data) throws Exception {
		logger.info("===============关联银行卡开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_sign_bank_acc.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============关联银行卡结束===============");
		return result;
	}
	
	/**
	 * 账户信息查询
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserQueryAcctInfo(UmpsApiData data) throws Exception {
		logger.info("===============账户信息查询开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_query_acct_info.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============账户信息查询结束===============");
		return result;
	}
	
	/**
	 * 查询账户交易明细
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserQueryTranDetail(UmpsApiData data) throws Exception {
		logger.info("===============查询账户交易明细开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_query_tran_detail.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============查询账户交易明细结束===============");
		return result;
	}
	
	/**
	 * 获取验证短信
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserVerifySms(UmpsApiData data) throws Exception {
		logger.info("===============获取验证短信开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_verify_sms.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============获取验证短信结束===============");
		return result;
	}
	
	/**
	 * 刷新登录凭证
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserRefreshToken(UmpsApiData data) throws Exception {
		logger.info("===============刷新登录凭证开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_refresh_token.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============刷新登录凭证结束===============");
		return result;
	}
	
	/**
	 * 验证码校验
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserVerifyCode(UmpsApiData data) throws Exception {
		logger.info("===============验证码校验开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_verify_code.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============验证码校验结束===============");
		return result;
	}
	
	/**
	 * 自助找回密码
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserResetPasswdSelf(UmpsApiData data) throws Exception {
		logger.info("===============自助找回密码开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_reset_passwd_self.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============自助找回密码结束===============");
		return result;
	}
	
	/**
	 * 精确查询单个会员资料
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserQueryCertainUserInfo(UmpsApiData data) throws Exception {
		logger.info("===============精确查询单个会员资料开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_query_certain_user_info.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============精确查询单个会员资料结束===============");
		return result;
	}
	
	/**
	 * 通过手机/邮箱查询卡信息
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserCardQuery(UmpsApiData data) throws Exception {
		logger.info("===============通过手机/邮箱查询卡信息开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_card_query.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============通过手机/邮箱查询卡信息结束===============");
		return result;
	}
	
	/**
	 * 关联手机号/邮箱
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserAccountBind(UmpsApiData data) throws Exception {
		logger.info("===============关联手机号/邮箱开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_account_bind.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============关联手机号/邮箱结束===============");
		return result;
	}
	
	/**
	 * 修改账户通登录密码
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUserModCustPasswd(UmpsApiData data) throws Exception {
		logger.info("===============修改账户通登录密码开始===============");
		String apiName = ApiNameDef.epaylinks_umps_user_mod_cust_passwd.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============修改账户通登录密码结束===============");
		return result;
	}
	
	/**
	 * 对私开户
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsFundOpenPersonalaccount(UmpsApiData data) throws Exception {
		logger.info("===============对私开户开始===============");
		String apiName = ApiNameDef.epaylinks_fund_open_personalaccount.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============对私开户结束===============");
		return result;
	}
	
	/**
	 * 转入
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsFundTransferIn(UmpsApiData data) throws Exception {
		logger.info("===============转入开始===============");
		String apiName = ApiNameDef.epaylinks_fund_transfer_in.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============转入结束===============");
		return result;
	}
	
	/**
	 * 转出
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsFundTransferOut(UmpsApiData data) throws Exception {
		logger.info("===============转出开始===============");
		String apiName = ApiNameDef.epaylinks_fund_transfer_out.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============转出结束===============");
		return result;
	}
	
	/**
	 * 查询账户余额信息
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsFundQueryAccountInfo(UmpsApiData data) throws Exception {
		logger.info("===============查询账户余额信息开始===============");
		String apiName = ApiNameDef.epaylinks_fund_query_accountinfo.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============查询账户余额信息结束===============");
		return result;
	}
	
	/**
	 * 基金信息查询
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsFundQueryFundList(UmpsApiData data) throws Exception {
		logger.info("===============基金信息查询开始===============");
		String apiName = ApiNameDef.epaylinks_fund_query_fund_list.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============基金信息查询结束===============");
		return result;
	}
	
	/**
	 * 交易记录查询
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsFundQueryTradeDetailList(UmpsApiData data) throws Exception {
		logger.info("===============交易记录查询开始===============");
		String apiName = ApiNameDef.epaylinks_fund_query_trade_detail_list.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============交易记录查询结束===============");
		return result;
	}
	
	/**
	 * 开户状态查询
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsFundQueryPersonalState(UmpsApiData data) throws Exception {
		logger.info("===============开户状态查询开始===============");
		String apiName = ApiNameDef.epaylinks_fund_query_personal_state.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============开户状态查询结束===============");
		return result;
	}
	
	/**
	 * 用户注册
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsWalletCustReg(UmpsApiData data) throws Exception {
		logger.info("===============用户注册开始===============");
		String apiName = ApiNameDef.epaylinks_wallet_cust_reg.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============用户注册结束===============");
		return result;
	}
	
	/**
	 * 新钱包登录
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsWalletCustLogin(UmpsApiData data) throws Exception {
		logger.info("===============新钱包登录开始===============");
		String apiName = ApiNameDef.epaylinks_wallet_cust_login.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============新钱包登录结束===============");
		return result;
	}
	
	/**
	 * 账号绑定卡查询接口
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsWalletCustCardQry(UmpsApiData data) throws Exception {
		logger.info("===============账号绑定卡查询开始===============");
		String apiName = ApiNameDef.epaylinks_wallet_cust_card_qry.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============账号绑定卡查询结束===============");
		return result;
	}
	
	/**
	 * 账号绑定卡操作
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsWalletOperCustCard(UmpsApiData data) throws Exception {
		logger.info("===============账号绑定卡操作开始===============");
		String apiName = ApiNameDef.epaylinks_wallet_oper_cust_card.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============账号绑定卡操作结束===============");
		return result;
	}
	
	/**
	 * 手机账号检测
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsWalletCheckMob(UmpsApiData data) throws Exception {
		logger.info("===============手机账号检测开始===============");
		String apiName = ApiNameDef.epaylinks_wallet_check_mob.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============手机账号检测结束===============");
		return result;
	}
	
	/**
	 * 账户切换接口
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsWalletChangeAccount(UmpsApiData data) throws Exception {
		logger.info("===============账户切换接口开始===============");
		String apiName = ApiNameDef.epaylinks_wallet_change_account.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============账户切换接口结束===============");
		return result;
	}
	
	/**
	 * 实名认证非敏感信息修改
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsWalletModRealnameInfo(UmpsApiData data) throws Exception {
		logger.info("===============实名认证非敏感信息修改开始===============");
		String apiName = ApiNameDef.epaylinks_wallet_mod_realname_info.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============实名认证非敏感信息修改结束===============");
		return result;
	}
	
	/**
	 * 网关支付-纯前台类交易
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public void umpsGatewayPay(String url,UmpsApiData data,HttpServletResponse response,String encoding) throws Exception {
		logger.info("===============网关支付开始===============");
		String apiName = ApiNameDef.epaylinks_gateway_pay.toString();
		sendHtmlUmps(url, data, response, encoding, apiName);
        logger.info("===============网关支付结束===============");
	}
	
	/**
	 * 网关支付状态查询
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsGatewayStatusQuery(UmpsApiData data) throws Exception {
		logger.info("===============网关支付状态查询开始===============");
		String apiName = ApiNameDef.epaylinks_gateway_status_query.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============网关支付状态查询结束===============");
		return result;
	}
	
	/**
	 * 网关支付退款
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsGatewayRefund(UmpsApiData data) throws Exception {
		logger.info("===============网关支付退款开始===============");
		String apiName = ApiNameDef.epaylinks_gateway_refund.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============网关支付退款结束===============");
		return result;
	}
	
	/**
	 * 网关支付退款查询
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsGatewayRefundQuery(UmpsApiData data) throws Exception {
		logger.info("===============网关支付退款查询开始===============");
		String apiName = ApiNameDef.epaylinks_gateway_refund_query.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============网关支付退款查询结束===============");
		return result;
	}
	
	/**
	 * 账户充值--前台类交易
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public void umpsTransAccountRecharge(String url,UmpsApiData data,HttpServletResponse response,String encoding) throws Exception {
		logger.info("===============账户充值开始===============");
		String apiName = ApiNameDef.epaylinks_trans_account_recharge.toString();
		this.sendHtmlUmps(url, data, response, encoding, apiName);
        logger.info("===============账户充值结束===============");
	}
	
	/**
	 * 账户充值--后台类交易
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsTransAccountRecharge(UmpsApiData data) throws Exception {
		logger.info("===============账户充值开始===============");
		String apiName = ApiNameDef.epaylinks_trans_account_recharge.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============账户充值结束===============");
		return result;
	}
	
	
	/**
	 * 账户消费--前台交易
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public void umpsTransAccountConsume(String url,UmpsApiData data,HttpServletResponse response,String encoding) throws Exception {
		logger.info("===============账户消费开始===============");
		String apiName = ApiNameDef.epaylinks_trans_account_consume.toString();
		this.sendHtmlUmps(url, data, response, encoding, apiName);
        logger.info("===============账户消费结束===============");
	}
	
	/**
	 * 账户消费--后台交易
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsTransAccountConsume(UmpsApiData data) throws Exception {
		logger.info("===============账户消费开始===============");
		String apiName = ApiNameDef.epaylinks_trans_account_consume.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============账户消费结束===============");
		return result;
	}
	
	/**
	 * 批量支付及报关
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsTransAccountPayReport(UmpsApiData data,List<HashMap<String,Object>> details) throws Exception {
		logger.info("===============批量支付及报关开始===============");
		String apiName = ApiNameDef.epaylinks_trans_account_pay_report.toString();
		data.setRequestParam("order_detail", JSONObject.toJSONString(details));
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============批量支付及报关结束===============");
		return result;
	}
	
	/**
	 * 账户转账
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsTransAccountTransfer(UmpsApiData data) throws Exception {
		logger.info("===============账户转账开始===============");
		String apiName = ApiNameDef.epaylinks_trans_account_transfer.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============账户转账结束===============");
		return result;
	}
	
	/**
	 * 批量转账
	 * 从一个支付账户批量转账到其他支付账户。交易结果需要通过“交易状态查询”接口异步查询得到。
	 * @param data
	 * @return
	 * @throws Exception 
	 */
	public SortedMap<String,String> umpsAccountTransferBatch(UmpsApiData data,List<HashMap<String,Object>> details) throws Exception {
		logger.info("===============批量转账请求开始===============");
		//设置默认参数
		data.setRequestParam("trans_type", "0400");
		//分装交易详细参数
		data.setRequestParam("trans_detail", JSONObject.toJSONString(details));
		String apiName = ApiNameDef.epaylinks_trans_account_transfer_batch.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============批量转账结束===============");
		return result;
	}
	
	/**
	 * 账户提现
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsTransAccountWithdraw(UmpsApiData data) throws Exception {
		logger.info("===============账户提现开始===============");
		String apiName = ApiNameDef.epaylinks_trans_account_withdraw.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============账户提现结束===============");
		return result;
	}
	
	/**
	 * 批量转账到银行(代付)
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsTransAccountTransferTobankBatch(UmpsApiData data,List<HashMap<String,Object>> details) throws Exception {
		logger.info("===============批量转账到银行(代付)开始===============");
		String apiName = ApiNameDef.epaylinks_trans_account_transfer_tobank_batch.toString();
		data.setRequestParam("trans_detail", JSONObject.toJSONString(details));
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============批量转账到银行(代付)结束===============");
		return result;
	}
	
	/**
	 * 交易状态查询
	 * 当商户系统未收到交易结果通知或无法确定交易状态时，可通过发送该查询确定交易的状态。该交易为后台类交易。
	 * @param data
	 * @return
	 * @throws Exception 
	 */
	public SortedMap<String,String> umpsTransStatusQuery(UmpsApiData data) throws Exception {
		logger.info("===============交易状态查询请求开始===============");
		//设置默认参数
		data.setRequestParam("trans_type", "0701");
		String apiName = ApiNameDef.epaylinks_trans_status_query.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============交易状态查询开始===============");
		return result;
	}
	
	/**
	 * 可领取会员卡商家列表查询
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsMerchantListQry(UmpsApiData data) throws Exception {
		logger.info("===============可领取会员卡商家列表查询开始===============");
		String apiName = ApiNameDef.epaylinks_umps_merchant_list_qry.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============可领取会员卡商家列表查询结束===============");
		return result;
	}
	
	/**
	 * 查询商户使用门店接口
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsMemberApplyStoresQry(UmpsApiData data) throws Exception {
		logger.info("===============查询商户使用门店开始===============");
		String apiName = ApiNameDef.epaylinks_umps_member_apply_stores_qry.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============查询商户使用门店结束===============");
		return result;
	}
	
	/**
	 * 查询商家会员卡列表
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsMemberCardListQry(UmpsApiData data) throws Exception {
		logger.info("===============查询商家会员卡列表开始===============");
		String apiName = ApiNameDef.epaylinks_umps_member_card_list_qry.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============查询商家会员卡列表结束===============");
		return result;
	}
	
	/**
	 * 虚拟会员卡申领
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsVirtualMemberCardApply(UmpsApiData data) throws Exception {
		logger.info("===============虚拟会员卡申领开始===============");
		String apiName = ApiNameDef.epaylinks_umps_virtual_member_card_apply.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============虚拟会员卡申领结束===============");
		return result;
	}
	
	/**
	 * 会员卡信息查询
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsVirtualMemberCardQry(UmpsApiData data) throws Exception {
		logger.info("===============会员卡信息查询开始===============");
		String apiName = ApiNameDef.epaylinks_umps_virtual_member_card_qry.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============会员卡信息查询结束===============");
		return result;
	}
	
	/**
	 * 获取付款令牌接口
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsGetPayToken(UmpsApiData data) throws Exception {
		logger.info("===============获取付款令牌开始===============");
		String apiName = ApiNameDef.epaylinks_umps_get_pay_token.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============获取付款令牌结束===============");
		return result;
	}
	
	/**
	 * 文件上传
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsUtilFileUpload(UmpsApiData data) throws Exception {
		logger.info("===============文件上传开始===============");
		String apiName = ApiNameDef.epaylinks_util_file_upload.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============文件上传结束===============");
		return result;
	}
	
	/**
	 * 查询银行列表
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsPublicQueryBank(UmpsApiData data) throws Exception {
		logger.info("===============查询银行列表开始===============");
		String apiName = ApiNameDef.epaylinks_public_query_bank.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============查询银行列表结束===============");
		return result;
	}
	
	/**
	 * 查询开户地信息
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsPublicQueryArea(UmpsApiData data) throws Exception {
		logger.info("===============查询开户地信息开始===============");
		String apiName = ApiNameDef.epaylinks_public_query_area.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============查询开户地信息结束===============");
		return result;
	}
	
	/**
	 * 查询支行信息
	 * @param data
	 * @return
	 * @throws Exception
	 */
	public SortedMap<String,String> umpsPublicQueryBranch(UmpsApiData data) throws Exception {
		logger.info("===============查询支行信息开始===============");
		String apiName = ApiNameDef.epaylinks_public_query_branch.toString();
		SortedMap<String,String> result = sendUmps(data, apiName);
        logger.info("===============查询支行信息结束===============");
		return result;
	}
	
}
